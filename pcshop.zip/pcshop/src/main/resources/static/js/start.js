async function route() {
    var hash = location.hash || '#/';
    var parts = hash.slice(2).split('/');
    var page = parts[0];

    try {
        if (page === '') {
            await pageCatalog();
        } else if (page === 'product') {
            await pageProduct(parts[1]);
        } else if (page === 'cart') {
            await pageCart();
        } else if (page === 'orders') {
            await pageOrders();
        } else if (page === 'order') {
            await pageOrder(parts[1]);
        } else if (page === 'login') {
            pageLogin();
        } else if (page === 'register') {
            pageRegister();
        } else if (page === 'profile') {
            await pageProfile();
        } else if (page === 'config') {
            await pageConfig();
        } else if (page === 'staff') {
            await pageStaff();
        } else {
            app.innerHTML = '<h1>Страница не найдена</h1>';
        }
    } catch (e) {
        app.innerHTML = '<div class="error">' + esc(e.message) + '</div>';
    }
    window.scrollTo(0, 0);
}

async function start() {
    await loadMe();
    try {
        cats = flattenCats(await api('GET', '/categories'), 0, []);
        brands = await api('GET', '/brands');
    } catch (e) {
        app.innerHTML = '<div class="error">Не удалось загрузить данные: ' + esc(e.message) + '</div>';
        return;
    }
    renderNav();
    updateCartCount();
    route();
}

async function loadMe() {
    me = null;
    if (!token) {
        return;
    }
    try {
        me = await api('GET', '/users/me');
    } catch (e) {
        clearTokens();
    }
}

window.addEventListener('hashchange', route);
start();
