var cfgCats = [];
var chosen = {};
var allProducts = {};
var compatCache = {};
var checkResult = null;
var checkCounter = 0;
var savedConfigs = [];
var cfgName = '';
var pickerCat = null;
var pickerSearch = '';
var pickerSort = 'price_asc';
var pickerOnlyCompat = true;

var catOrder = ['Процессоры', 'Охлаждение процессора', 'Материнские платы', 'Оперативная память',
    'Накопители', 'Видеокарты', 'Блоки питания', 'Корпуса'];

var specLabels = {
    socket: function (v) { return 'сокет ' + v; },
    sockets: function (v) { return 'сокеты ' + v.replace(/,/g, ', '); },
    cooler_tdp_w: function (v) { return 'до ' + v + ' Вт'; },
    cooler_height_mm: function (v) { return 'высота ' + v + ' мм'; },
    max_cooler_height_mm: function (v) { return 'кулер до ' + v + ' мм'; },
    storage_type: function (v) { return v; },
    storage_capacity_gb: function (v) { return v >= 1000 ? (v / 1000) + ' ТБ' : v + ' ГБ'; },
    m2_slots: function (v) { return 'M.2: ' + v; },
    sata_ports: function (v) { return 'SATA: ' + v; },
    ram_type: function (v) { return v; },
    form_factor: function (v) { return v; },
    ram_slots: function (v) { return 'слотов памяти: ' + v; },
    tdp_w: function (v) { return 'TDP ' + v + ' Вт'; },
    ram_capacity_gb: function (v) { return v + ' ГБ'; },
    psu_power_w: function (v) { return v + ' Вт'; }
};

function specLine(p) {
    var parts = [];
    for (var k in specLabels) {
        if (p.specs[k]) {
            parts.push(specLabels[k](p.specs[k]));
        }
    }
    return parts.join(' · ');
}

function multiAllowed(p) {
    return p.specs.component === 'ram' || p.specs.component === 'storage';
}

function sortCats() {
    cfgCats = cats.slice().sort(function (a, b) {
        var x = catOrder.indexOf(a.name);
        var y = catOrder.indexOf(b.name);
        if (x === -1) {
            x = 100;
        }
        if (y === -1) {
            y = 100;
        }
        return x - y;
    });
}

async function pageConfig() {
    sortCats();
    chosen = {};
    checkResult = null;
    compatCache = {};
    cfgName = '';

    var lists = await Promise.all(cfgCats.map(function (c) {
        return api('GET', '/products?category_id=' + c.id + '&limit=100');
    }));
    allProducts = {};
    cfgCats.forEach(function (c, i) {
        allProducts[c.id] = lists[i].items;
    });

    app.innerHTML = '<h1>Конфигуратор ПК</h1>' +
        '<div class="cfg"><div class="cfg-main"><div class="box wrap" id="cfgTable"></div><div id="cfgSaved"></div></div>' +
        '<div class="cfg-side" id="cfgSide"></div></div>' +
        '<div id="picker"></div>';

    document.onkeydown = function (e) {
        if (e.key === 'Escape') {
            closePicker();
        }
    };

    drawTable();
    drawSide();
    loadSaved();
}

function chosenIds() {
    var ids = [];
    for (var c in chosen) {
        for (var i = 0; i < chosen[c].qty; i++) {
            ids.push(chosen[c].product.id);
        }
    }
    return ids;
}

function chosenTotal() {
    var sum = 0;
    for (var c in chosen) {
        sum += Number(chosen[c].product.price) * chosen[c].qty;
    }
    return sum;
}

function drawTable() {
    var rows = '';
    cfgCats.forEach(function (c) {
        var item = chosen[c.id];
        if (!item) {
            rows += '<tr><td class="slot">' + esc(c.name) + '</td>' +
                '<td class="muted">не выбрано</td><td></td>' +
                '<td class="right"><button class="small" onclick="openPicker(' + c.id + ')">Выбрать</button></td></tr>';
            return;
        }
        var p = item.product;
        var qty = '';
        if (multiAllowed(p)) {
            qty = '<div class="qty">Количество: <button class="small gray" onclick="changeQty(' + c.id + ', -1)">−</button> ' +
                '<b>' + item.qty + '</b> <button class="small gray" onclick="changeQty(' + c.id + ', 1)">+</button></div>';
        }
        rows += '<tr><td class="slot">' + esc(c.name) + '</td>' +
            '<td><div class="withthumb"><div class="thumbbox">' + productImg(p, '') + '</div><div><a href="#/product/' + p.id + '">' + esc(p.name) + '</a>' +
            '<div class="muted">' + esc(specLine(p)) + '</div>' + qty + '</div></div></td>' +
            '<td class="right nowrap">' + money(p.price * item.qty) + '</td>' +
            '<td class="right nowrap"><button class="small gray" onclick="openPicker(' + c.id + ')">Заменить</button> ' +
            '<button class="small red" onclick="removeSlot(' + c.id + ')">Убрать</button></td></tr>';
    });
    document.getElementById('cfgTable').innerHTML = '<table class="cfg-table">' +
        '<tr><th>Компонент</th><th>Выбрано</th><th class="right">Цена</th><th></th></tr>' + rows + '</table>';
}

function changeQty(catId, step) {
    var item = chosen[catId];
    item.qty = item.qty + step;
    if (item.qty < 1) {
        item.qty = 1;
    }
    if (item.qty > 8) {
        item.qty = 8;
    }
    drawTable();
    runCheck();
}

function removeSlot(catId) {
    delete chosen[catId];
    drawTable();
    runCheck();
}

function drawSide() {
    var ids = chosenIds();
    var count = Object.keys(chosen).length;

    var verdict = '';
    if (ids.length === 0) {
        verdict = '<div class="verdict">Выбери комплектующие, сборка проверится сама</div>';
    } else if (!checkResult) {
        verdict = '<div class="verdict">Проверяю…</div>';
    } else if (checkResult.compatible) {
        verdict = '<div class="verdict ok">Совместимо</div>';
    } else {
        verdict = '<div class="verdict bad"><b>Есть проблемы:</b><ul>';
        checkResult.errors.forEach(function (e) {
            verdict += '<li>' + esc(e) + '</li>';
        });
        verdict += '</ul></div>';
    }

    var extra = '';
    if (checkResult) {
        extra += '<div class="muted" style="margin-top:8px">Нужен блок питания от ' + checkResult.required_power_w + ' Вт</div>';
        checkResult.warnings.forEach(function (w) {
            extra += '<div class="muted" style="margin-top:4px">' + esc(w) + '</div>';
        });
    }

    var buttons = '<button class="full green" ' + (ids.length ? '' : 'disabled') + ' onclick="buildToCart()">Добавить всё в корзину</button>';
    if (me && me.role === 'customer') {
        buttons += '<label>Название сборки</label><input id="cfgName" value="' + esc(cfgName) + '" oninput="cfgName = this.value" placeholder="Например, Игровой ПК">' +
            '<button class="full" ' + (ids.length ? '' : 'disabled') + ' onclick="saveConfig()">Сохранить сборку</button>';
    } else {
        buttons += '<div class="muted" style="margin-top:10px"><a href="#/login">Войди как покупатель</a>, чтобы сохранять сборки и оформлять заказ</div>';
    }
    buttons += '<button class="full gray" ' + (ids.length ? '' : 'disabled') + ' onclick="clearBuild()">Очистить</button>';

    document.getElementById('cfgSide').innerHTML = '<div class="box">' +
        '<div class="sumrow"><span>Выбрано</span><b>' + count + ' из ' + cfgCats.length + '</b></div>' +
        '<div class="sumrow"><span>Итого</span><b class="big">' + money(chosenTotal()) + '</b></div>' +
        verdict + extra + buttons + '</div>';
}

async function runCheck() {
    var ids = chosenIds();
    var myId = ++checkCounter;
    checkResult = null;
    drawSide();
    if (ids.length === 0) {
        return;
    }
    try {
        var result = await api('POST', '/configurator/check', { product_ids: ids });
        if (myId === checkCounter) {
            checkResult = result;
            drawSide();
        }
    } catch (e) {
        if (myId === checkCounter) {
            toast(e.message, true);
        }
    }
}

function clearBuild() {
    chosen = {};
    drawTable();
    runCheck();
}

async function compatibleIds(baseId, catId) {
    var key = baseId + '-' + catId;
    if (!compatCache[key]) {
        var list = await api('GET', '/configurator/compatible-products?base_product_id=' + baseId + '&category_id=' + catId);
        compatCache[key] = list.map(function (p) { return p.id; });
    }
    return compatCache[key];
}

async function openPicker(catId) {
    pickerCat = catId;
    pickerSearch = '';
    pickerSort = 'price_asc';
    var cat = cfgCats.find(function (c) { return c.id == catId; });

    document.getElementById('picker').innerHTML = '<div class="overlay" onclick="closePicker()"><div class="modal" onclick="event.stopPropagation()">' +
        '<div class="modal-head"><h2 style="margin:0">' + esc(cat.name) + '</h2>' +
        '<button class="gray small" onclick="closePicker()">Закрыть</button></div>' +
        '<div class="row" style="margin-top:12px"><input placeholder="Поиск по названию" oninput="pickerSearch = this.value; drawPickerList()">' +
        '<select onchange="pickerSort = this.value; drawPickerList()">' +
        '<option value="price_asc">Сначала дешёвые</option><option value="price_desc">Сначала дорогие</option><option value="name">По названию</option></select></div>' +
        '<div class="check"><input type="checkbox" ' + (pickerOnlyCompat ? 'checked' : '') + ' onchange="pickerOnlyCompat = this.checked; drawPickerList()">Только совместимые с уже выбранным</div>' +
        '<div id="pickList" style="margin-top:8px"></div></div></div>';
    await drawPickerList();
}

function closePicker() {
    var el = document.getElementById('picker');
    if (el) {
        el.innerHTML = '';
    }
}

async function drawPickerList() {
    var okIds = null;
    for (var other in chosen) {
        if (other == pickerCat) {
            continue;
        }
        var ids = await compatibleIds(chosen[other].product.id, pickerCat);
        if (okIds === null) {
            okIds = ids.slice();
        } else {
            okIds = okIds.filter(function (id) { return ids.indexOf(id) !== -1; });
        }
    }

    var list = allProducts[pickerCat].slice();
    var text = pickerSearch.trim().toLowerCase();
    list = list.filter(function (p) {
        return text === '' || p.name.toLowerCase().indexOf(text) !== -1;
    });
    if (pickerSort === 'price_asc') {
        list.sort(function (a, b) { return a.price - b.price; });
    } else if (pickerSort === 'price_desc') {
        list.sort(function (a, b) { return b.price - a.price; });
    } else {
        list.sort(function (a, b) { return a.name.localeCompare(b.name); });
    }

    var html = '';
    list.forEach(function (p) {
        var fits = okIds === null || okIds.indexOf(p.id) !== -1;
        if (!fits && pickerOnlyCompat) {
            return;
        }
        var stock = p.stock_quantity > 0 ? 'в наличии: ' + p.stock_quantity : 'нет в наличии';
        var current = chosen[pickerCat] && chosen[pickerCat].product.id === p.id;
        html += '<div class="prow' + (fits ? '' : ' dim') + '">' +
            '<div class="thumbbox">' + productImg(p, '') + '</div>' +
            '<div style="flex:1"><div><b>' + esc(p.name) + '</b>' + (fits ? '' : ' <span class="no">не подходит к выбранному</span>') + '</div>' +
            '<div class="muted">' + esc(brandName(p.brand_id)) + (specLine(p) ? ' · ' + esc(specLine(p)) : '') + ' · ' + stock + '</div></div>' +
            '<div class="nowrap"><b>' + money(p.price) + '</b></div>' +
            '<button class="small" ' + (p.stock_quantity > 0 && !current ? '' : 'disabled') + ' onclick="pickProduct(' + p.id + ')">' +
            (current ? 'Выбрано' : 'Выбрать') + '</button></div>';
    });
    if (html === '') {
        html = '<p class="muted">Ничего не найдено. Можно снять галочку «только совместимые».</p>';
    }

    var box = document.getElementById('pickList');
    if (box) {
        box.innerHTML = html;
    }
}

function pickProduct(productId) {
    var p = allProducts[pickerCat].find(function (x) { return x.id === productId; });
    var qty = 1;
    if (chosen[pickerCat] && multiAllowed(chosen[pickerCat].product)) {
        qty = chosen[pickerCat].qty;
    }
    chosen[pickerCat] = { product: p, qty: qty };
    closePicker();
    drawTable();
    runCheck();
}

async function buildToCart() {
    if (!me || me.role !== 'customer') {
        toast('Войди как покупатель, чтобы добавить в корзину', true);
        return;
    }
    if (checkResult && !checkResult.compatible) {
        if (!confirm('Сборка не прошла проверку совместимости. Всё равно добавить в корзину?')) {
            return;
        }
    }
    try {
        for (var c in chosen) {
            await api('POST', '/cart/items', { product_id: chosen[c].product.id, quantity: chosen[c].qty });
        }
        toast('Добавлено в корзину');
        updateCartCount();
    } catch (e) {
        toast(e.message, true);
    }
}

async function saveConfig() {
    try {
        await api('POST', '/configurations', { name: cfgName, product_ids: chosenIds() });
        toast('Сборка сохранена');
        cfgName = '';
        drawSide();
        loadSaved();
    } catch (e) {
        toast(e.message, true);
    }
}

function findProduct(id) {
    for (var c in allProducts) {
        var p = allProducts[c].find(function (x) { return x.id === id; });
        if (p) {
            return p;
        }
    }
    return null;
}

async function loadSaved() {
    var box = document.getElementById('cfgSaved');
    if (!box || !me || me.role !== 'customer') {
        return;
    }
    savedConfigs = await api('GET', '/configurations');

    var rows = '';
    savedConfigs.forEach(function (c) {
        var sum = 0;
        c.product_ids.forEach(function (id) {
            var p = findProduct(id);
            if (p) {
                sum += Number(p.price);
            }
        });
        rows += '<tr><td><b>' + esc(c.name) + '</b></td><td>' + c.product_ids.length + ' шт.</td><td class="right nowrap">' + money(sum) + '</td>' +
            '<td class="right nowrap"><button class="small gray" onclick="openSaved(' + c.id + ')">Открыть</button> ' +
            '<button class="small" onclick="savedToCart(' + c.id + ')">В корзину</button></td></tr>';
    });
    if (rows === '') {
        rows = '<tr><td colspan="4" class="muted">Сохранённых сборок пока нет</td></tr>';
    }
    box.innerHTML = '<h2>Мои сборки</h2><div class="box wrap"><table class="cfg-table">' + rows + '</table></div>';
}

function openSaved(id) {
    var config = savedConfigs.find(function (c) { return c.id === id; });
    chosen = {};
    config.product_ids.forEach(function (pid) {
        var p = findProduct(pid);
        if (!p) {
            return;
        }
        if (chosen[p.category_id]) {
            chosen[p.category_id].qty++;
        } else {
            chosen[p.category_id] = { product: p, qty: 1 };
        }
    });
    cfgName = config.name;
    drawTable();
    runCheck();
    window.scrollTo(0, 0);
}

async function savedToCart(id) {
    try {
        await api('POST', '/configurations/' + id + '/to-cart');
        toast('Добавлено в корзину');
        updateCartCount();
    } catch (e) {
        toast(e.message, true);
    }
}
