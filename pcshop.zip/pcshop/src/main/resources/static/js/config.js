var chosen = {};
var allProducts = {};
var onlyCompatible = true;
var checkResult = null;
var compatCache = {};

async function pageConfig() {
    chosen = {};
    checkResult = null;
    allProducts = {};
    compatCache = {};

    for (var i = 0; i < cats.length; i++) {
        var data = await api('GET', '/products?category_id=' + cats[i].id + '&limit=100');
        allProducts[cats[i].id] = data.items;
    }

    app.innerHTML = '<h1>Конфигуратор ПК</h1>' +
        '<p class="muted">Выбери комплектующие по одной в каждой категории. Если включена галочка, в списках остаются только те, что подходят к уже выбранным.</p>' +
        '<div class="layout"><div class="content"><div class="box" id="slots"></div></div>' +
        '<div class="side" style="width:340px"><div class="box" id="cfgResult"></div><div id="cfgSaved"></div></div></div>';

    await drawSlots();
    drawResult();
    loadSavedConfigs();
}

async function compatibleIds(baseId, catId) {
    var key = baseId + '-' + catId;
    if (!compatCache[key]) {
        var list = await api('GET', '/configurator/compatible-products?base_product_id=' + baseId + '&category_id=' + catId);
        compatCache[key] = list.map(function (p) { return p.id; });
    }
    return compatCache[key];
}

async function drawSlots() {
    var html = '<div class="check" style="margin:0 0 10px"><input type="checkbox" id="onlyCompat" ' +
        (onlyCompatible ? 'checked' : '') + ' onchange="toggleCompat()">Показывать только совместимые</div>';

    for (var i = 0; i < cats.length; i++) {
        var cat = cats[i];
        var list = allProducts[cat.id];

        if (onlyCompatible) {
            for (var other in chosen) {
                if (other == cat.id) {
                    continue;
                }
                var ids = await compatibleIds(chosen[other], cat.id);
                list = list.filter(function (p) { return ids.indexOf(p.id) !== -1; });
            }
        }

        var options = '<option value="">— не выбрано —</option>';
        list.forEach(function (p) {
            var sel = chosen[cat.id] == p.id ? ' selected' : '';
            options += '<option value="' + p.id + '"' + sel + '>' + esc(p.name) + ' — ' + money(p.price) + '</option>';
        });
        html += '<label>' + esc(cat.name) + ' <span class="muted">(доступно: ' + list.length + ')</span></label>' +
            '<select onchange="pickProduct(' + cat.id + ', this.value)">' + options + '</select>';
    }
    document.getElementById('slots').innerHTML = html;
}

async function toggleCompat() {
    onlyCompatible = document.getElementById('onlyCompat').checked;
    await drawSlots();
}

async function pickProduct(catId, productId) {
    if (productId === '') {
        delete chosen[catId];
    } else {
        chosen[catId] = Number(productId);
    }
    checkResult = null;
    await drawSlots();
    drawResult();
}

function chosenIds() {
    var ids = [];
    for (var c in chosen) {
        ids.push(chosen[c]);
    }
    return ids;
}

function drawResult() {
    var ids = chosenIds();
    var sum = 0;
    var lines = '';
    for (var c in chosen) {
        var p = allProducts[c].find(function (x) { return x.id == chosen[c]; });
        if (p) {
            sum += Number(p.price);
            lines += '<div>' + esc(p.name) + ' — ' + money(p.price) + '</div>';
        }
    }
    if (lines === '') {
        lines = '<div class="muted">Пока ничего не выбрано</div>';
    }

    var html = '<h2 style="margin-top:0">Сборка</h2>' + lines +
        '<div class="total">Итого: ' + money(sum) + '</div>' +
        '<button class="full" ' + (ids.length ? '' : 'disabled') + ' onclick="runCheck()">Проверить совместимость</button>';

    if (checkResult) {
        if (checkResult.compatible) {
            html += '<div class="good">Комплектующие совместимы. Нужна мощность БП от ' + checkResult.required_power_w + ' Вт</div>';
        } else {
            html += '<div class="error" style="margin-top:8px">Есть проблемы:<br>' + checkResult.errors.map(esc).join('<br>') + '</div>';
        }
        if (checkResult.warnings.length) {
            html += '<div class="warn">' + checkResult.warnings.map(esc).join('<br>') + '</div>';
        }
    }

    if (me && me.role === 'customer') {
        html += '<label>Название сборки</label><input id="cfgName" placeholder="Например, Игровой ПК">' +
            '<button class="full green" ' + (ids.length ? '' : 'disabled') + ' onclick="saveConfig()">Сохранить сборку</button>';
    } else {
        html += '<p class="muted">Чтобы сохранить сборку и добавить в корзину, <a href="#/login">войди как покупатель</a></p>';
    }
    document.getElementById('cfgResult').innerHTML = html;
}

async function runCheck() {
    try {
        checkResult = await api('POST', '/configurator/check', { product_ids: chosenIds() });
        drawResult();
    } catch (e) {
        toast(e.message, true);
    }
}

async function saveConfig() {
    try {
        await api('POST', '/configurations', { name: val('cfgName'), product_ids: chosenIds() });
        toast('Сборка сохранена');
        loadSavedConfigs();
    } catch (e) {
        toast(e.message, true);
    }
}

async function loadSavedConfigs() {
    var box = document.getElementById('cfgSaved');
    if (!box || !me || me.role !== 'customer') {
        return;
    }
    var list = await api('GET', '/configurations');
    var html = '<h2>Мои сборки</h2>';
    if (list.length === 0) {
        html += '<div class="box muted">Сохранённых сборок нет</div>';
    }
    list.forEach(function (c) {
        html += '<div class="box"><b>' + esc(c.name) + '</b><div class="muted">товаров: ' + c.product_ids.length + '</div>' +
            '<button class="small" style="margin-top:6px" onclick="configToCart(' + c.id + ')">Всё в корзину</button></div>';
    });
    box.innerHTML = html;
}

async function configToCart(id) {
    try {
        await api('POST', '/configurations/' + id + '/to-cart');
        toast('Добавлено в корзину');
        updateCartCount();
    } catch (e) {
        toast(e.message, true);
    }
}
