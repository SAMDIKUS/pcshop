var token = localStorage.getItem('access');
var refresh = localStorage.getItem('refresh');
var me = null;

function saveTokens(a, r) {
    token = a;
    refresh = r;
    localStorage.setItem('access', a);
    localStorage.setItem('refresh', r);
}

function clearTokens() {
    token = null;
    refresh = null;
    me = null;
    localStorage.removeItem('access');
    localStorage.removeItem('refresh');
}

async function tryRefresh() {
    if (!refresh) {
        return false;
    }
    try {
        var res = await fetch('/auth/refresh', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ refresh_token: refresh })
        });
        if (!res.ok) {
            return false;
        }
        var data = await res.json();
        saveTokens(data.access_token, data.refresh_token);
        return true;
    } catch (e) {
        return false;
    }
}

async function api(method, url, body, retry) {
    var headers = {};
    if (body) {
        headers['Content-Type'] = 'application/json';
    }
    if (token) {
        headers['Authorization'] = 'Bearer ' + token;
    }

    var res = await fetch(url, {
        method: method,
        headers: headers,
        body: body ? JSON.stringify(body) : undefined
    });

    if (res.status === 401 && token && !retry) {
        var ok = await tryRefresh();
        if (ok) {
            return api(method, url, body, true);
        }
        clearTokens();
    }

    var text = await res.text();
    var data = null;
    if (text) {
        try {
            data = JSON.parse(text);
        } catch (e) {
            data = text;
        }
    }

    if (!res.ok) {
        var msg = 'Ошибка ' + res.status;
        if (data && data.message) {
            msg = data.message;
        } else if (res.status === 401) {
            msg = 'Нужно войти в аккаунт';
        } else if (res.status === 403) {
            msg = 'Нет доступа';
        }
        throw new Error(msg);
    }
    return data;
}
