var staffTab = '';
var staffStatus = '';
var editing = null;

function tabsForRole() {
    if (me.role === 'manager') {
        return [['orders', 'Заказы'], ['returns', 'Возвраты']];
    }
    if (me.role === 'storekeeper') {
        return [['stock', 'Склад'], ['supply', 'Поставки'], ['writeoff', 'Списание']];
    }
    return [['stock', 'Склад'], ['supply', 'Поставки'], ['writeoff', 'Списание'], ['products', 'Товары'],
        ['users', 'Пользователи'], ['promo', 'Промокоды'], ['analytics', 'Аналитика']];
}

async function pageStaff() {
    if (!me || me.role === 'customer') {
        location.hash = '#/login';
        return;
    }
    var tabs = tabsForRole();
    var found = tabs.find(function (t) { return t[0] === staffTab; });
    if (!found) {
        staffTab = tabs[0][0];
    }

    var html = '<h1>Панель сотрудника</h1><div class="tabs">';
    tabs.forEach(function (t) {
        html += '<button class="' + (t[0] === staffTab ? 'active' : '') + '" onclick="openTab(\'' + t[0] + '\')">' + t[1] + '</button>';
    });
    html += '</div><div id="staffBody"></div>';
    app.innerHTML = html;
    await drawTab();
}

function openTab(name) {
    staffTab = name;
    editing = null;
    pageStaff();
}

async function drawTab() {
    var body = document.getElementById('staffBody');
    try {
        if (staffTab === 'orders') {
            body.innerHTML = await tabOrders();
        } else if (staffTab === 'returns') {
            body.innerHTML = await tabReturns();
        } else if (staffTab === 'stock') {
            body.innerHTML = await tabStock();
        } else if (staffTab === 'supply') {
            body.innerHTML = await tabSupply();
        } else if (staffTab === 'writeoff') {
            body.innerHTML = await tabWriteOff();
        } else if (staffTab === 'products') {
            body.innerHTML = await tabProducts();
        } else if (staffTab === 'users') {
            body.innerHTML = await tabUsers();
        } else if (staffTab === 'promo') {
            body.innerHTML = await tabPromo();
        } else if (staffTab === 'analytics') {
            body.innerHTML = await tabAnalytics();
        }
    } catch (e) {
        body.innerHTML = '<div class="error">' + esc(e.message) + '</div>';
    }
}

async function tabOrders() {
    var orders = await api('GET', '/orders' + (staffStatus ? '?status=' + staffStatus : ''));
    var order = ['new', 'processing', 'assembled', 'shipped', 'delivered'];

    var filterOpts = '<option value="">Все статусы</option>';
    order.concat(['cancelled']).forEach(function (s) {
        filterOpts += '<option value="' + s + '"' + (staffStatus === s ? ' selected' : '') + '>' + statusNames[s] + '</option>';
    });

    var rows = '';
    orders.forEach(function (o) {
        var controls = '<span class="muted">закрыт</span>';
        if (o.status !== 'delivered' && o.status !== 'cancelled') {
            var next = '<option value="">Сменить статус…</option>';
            order.slice(order.indexOf(o.status) + 1).forEach(function (s) {
                next += '<option value="' + s + '">' + statusNames[s] + '</option>';
            });
            next += '<option value="cancelled">Отменить</option>';
            controls = '<select id="st-' + o.id + '" onchange="changeOrderStatus(' + o.id + ')">' + next + '</select>';
        }
        rows += '<tr><td>№' + o.id + '</td><td>' + fmtDate(o.created_at) + '</td><td>клиент #' + o.user_id + '</td>' +
            '<td>' + money(o.total) + (Number(o.discount) > 0 ? '<div class="muted">скидка ' + money(o.discount) + '</div>' : '') + '</td>' +
            '<td>' + statusTag(o.status) + '</td><td>' + controls + '</td></tr>';
    });
    if (rows === '') {
        rows = '<tr><td colspan="6">Заказов нет</td></tr>';
    }

    return '<div class="box" style="max-width:260px"><label>Фильтр по статусу</label>' +
        '<select onchange="staffStatus = this.value; drawTab();">' + filterOpts + '</select></div>' +
        '<div class="box wrap"><table><tr><th>Заказ</th><th>Дата</th><th>Клиент</th><th>Сумма</th><th>Статус</th><th>Действия</th></tr>' + rows + '</table></div>';
}

async function changeOrderStatus(id) {
    var v = val('st-' + id);
    if (v === '') {
        return;
    }
    try {
        await api('PATCH', '/orders/' + id + '/status', { status: v });
        toast('Статус изменён');
    } catch (e) {
        toast(e.message, true);
    }
    drawTab();
}

async function tabReturns() {
    var list = await api('GET', '/returns');
    var rows = '';
    list.forEach(function (r) {
        var btns = '';
        if (r.status === 'new') {
            btns = '<button class="small green" onclick="decideReturn(' + r.id + ', \'approved\')">Одобрить</button> ' +
                '<button class="small red" onclick="decideReturn(' + r.id + ', \'rejected\')">Отклонить</button>';
        } else if (r.status === 'approved') {
            btns = '<button class="small" onclick="decideReturn(' + r.id + ', \'completed\')">Завершить</button>';
        }
        rows += '<tr><td>№' + r.id + '</td><td>Заказ №' + r.order_id + '</td><td>' + (r.type === 'return' ? 'Возврат' : 'Обмен') + '</td>' +
            '<td>' + esc(r.reason) + '</td><td>' + statusTag(r.status) + '</td><td>' + btns + '</td></tr>';
    });
    if (rows === '') {
        rows = '<tr><td colspan="6">Заявок нет</td></tr>';
    }
    return '<div class="box wrap"><table><tr><th>№</th><th>Заказ</th><th>Тип</th><th>Причина</th><th>Статус</th><th></th></tr>' + rows + '</table></div>';
}

async function decideReturn(id, status) {
    try {
        await api('PATCH', '/returns/' + id, { status: status });
        toast('Готово');
    } catch (e) {
        toast(e.message, true);
    }
    drawTab();
}

async function tabStock() {
    var stock = await api('GET', '/stock');
    var moves = await api('GET', '/stock/movements');

    var rows = '';
    stock.forEach(function (s) {
        var low = s.stock_quantity <= 5;
        rows += '<tr><td>' + s.product_id + '</td><td>' + esc(s.sku) + '</td><td>' + esc(s.name) + '</td>' +
            '<td class="' + (low ? 'no' : '') + '"><b>' + s.stock_quantity + '</b>' + (low ? ' — мало' : '') + '</td>' +
            '<td>' + (s.is_active ? 'да' : 'нет') + '</td></tr>';
    });

    var typeNames = { supply: 'Приход', sale: 'Продажа', write_off: 'Списание' };
    var moveRows = '';
    moves.slice(0, 30).forEach(function (m) {
        moveRows += '<tr><td>' + fmtDate(m.created_at) + '</td><td>товар #' + m.product_id + '</td>' +
            '<td>' + (typeNames[m.type] || m.type) + '</td><td>' + m.quantity + '</td><td>' + esc(m.reason) + '</td></tr>';
    });
    if (moveRows === '') {
        moveRows = '<tr><td colspan="5">Движений нет</td></tr>';
    }

    return '<div class="box wrap"><table><tr><th>ID</th><th>Артикул</th><th>Название</th><th>Остаток</th><th>Активен</th></tr>' + rows + '</table></div>' +
        '<h2>Последние движения</h2><div class="box wrap"><table><tr><th>Дата</th><th>Товар</th><th>Тип</th><th>Кол-во</th><th>Причина</th></tr>' + moveRows + '</table></div>';
}

var productOptionsHtml = '';

async function tabSupply() {
    var suppliers = await api('GET', '/suppliers');
    var products = await api('GET', '/products?limit=100');

    var supOpts = '';
    suppliers.forEach(function (s) { supOpts += '<option value="' + s.id + '">' + esc(s.name) + '</option>'; });

    productOptionsHtml = '';
    products.items.forEach(function (p) {
        productOptionsHtml += '<option value="' + p.id + '">' + esc(p.name) + '</option>';
    });

    var supplies = await api('GET', '/supplies');
    var rows = '';
    supplies.forEach(function (s) {
        var total = 0;
        s.items.forEach(function (i) { total += i.quantity; });
        rows += '<tr><td>№' + s.id + '</td><td>' + fmtDate(s.date) + '</td><td>поставщик #' + s.supplier_id + '</td><td>' + total + ' шт.</td></tr>';
    });
    if (rows === '') {
        rows = '<tr><td colspan="4">Поставок ещё не было</td></tr>';
    }

    setTimeout(addSupplyRow, 0);

    return '<div class="box"><h2 style="margin-top:0">Новая поставка</h2>' +
        '<label>Поставщик</label><select id="sp-supplier">' + supOpts + '</select>' +
        '<div id="supplyRows"></div>' +
        '<button class="gray small" style="margin-top:10px" onclick="addSupplyRow()">+ Ещё товар</button> ' +
        '<button style="margin-top:10px" onclick="sendSupply()">Принять поставку</button></div>' +
        '<div class="box"><h2 style="margin-top:0">Новый поставщик</h2>' +
        '<div class="row"><input id="ns-name" placeholder="Название"><input id="ns-contacts" placeholder="Контакты"></div>' +
        '<button class="small" style="margin-top:10px" onclick="addSupplier()">Добавить</button></div>' +
        '<h2>История поставок</h2><div class="box wrap"><table><tr><th>№</th><th>Дата</th><th>Поставщик</th><th>Всего</th></tr>' + rows + '</table></div>';
}

function addSupplyRow() {
    var box = document.getElementById('supplyRows');
    if (!box) {
        return;
    }
    box.insertAdjacentHTML('beforeend', '<div class="row supplyRow" style="margin-top:8px">' +
        '<select class="sp-product">' + productOptionsHtml + '</select>' +
        '<input class="sp-qty" type="number" min="1" placeholder="Кол-во">' +
        '<input class="sp-price" type="number" min="0" placeholder="Закупочная цена"></div>');
}

async function sendSupply() {
    var items = [];
    document.querySelectorAll('.supplyRow').forEach(function (r) {
        var qty = Number(r.querySelector('.sp-qty').value);
        var price = r.querySelector('.sp-price').value;
        if (qty > 0 && price !== '') {
            items.push({
                product_id: Number(r.querySelector('.sp-product').value),
                quantity: qty,
                purchase_price: Number(price)
            });
        }
    });
    try {
        await api('POST', '/supplies', { supplier_id: Number(val('sp-supplier')), items: items });
        toast('Поставка принята');
        drawTab();
    } catch (e) {
        toast(e.message, true);
    }
}

async function addSupplier() {
    try {
        await api('POST', '/suppliers', { name: val('ns-name'), contacts: val('ns-contacts') });
        toast('Поставщик добавлен');
        drawTab();
    } catch (e) {
        toast(e.message, true);
    }
}

async function tabWriteOff() {
    var products = await api('GET', '/products?limit=100');
    var opts = '';
    products.items.forEach(function (p) {
        opts += '<option value="' + p.id + '">' + esc(p.name) + ' (остаток ' + p.stock_quantity + ')</option>';
    });
    return '<div class="box" style="max-width:460px"><h2 style="margin-top:0">Списание товара</h2>' +
        '<label>Товар</label><select id="wo-product">' + opts + '</select>' +
        '<label>Количество</label><input id="wo-qty" type="number" min="1">' +
        '<label>Причина</label><input id="wo-reason" placeholder="Брак, повреждение...">' +
        '<button class="full red" onclick="sendWriteOff()">Списать</button></div>';
}

async function sendWriteOff() {
    try {
        await api('POST', '/stock/write-offs', {
            product_id: Number(val('wo-product')),
            quantity: Number(val('wo-qty')),
            reason: val('wo-reason')
        });
        toast('Списано');
        drawTab();
    } catch (e) {
        toast(e.message, true);
    }
}

async function tabProducts() {
    var data = await api('GET', '/products?limit=100');

    var catOpts = '';
    cats.forEach(function (c) {
        catOpts += '<option value="' + c.id + '"' + (editing && editing.category_id == c.id ? ' selected' : '') + '>' + esc(c.name) + '</option>';
    });
    var brandOpts = '';
    brands.forEach(function (b) {
        brandOpts += '<option value="' + b.id + '"' + (editing && editing.brand_id == b.id ? ' selected' : '') + '>' + esc(b.name) + '</option>';
    });

    var specText = '';
    if (editing) {
        for (var k in editing.specs) {
            specText += k + '=' + editing.specs[k] + '\n';
        }
    }
    var e = editing || { sku: '', name: '', description: '', price: '', stock_quantity: 0 };

    var rows = '';
    data.items.forEach(function (p) {
        rows += '<tr><td>' + p.id + '</td><td>' + esc(p.sku) + '</td><td>' + esc(p.name) + '</td><td>' + money(p.price) + '</td>' +
            '<td>' + p.stock_quantity + '</td><td><button class="small gray" onclick="editProduct(' + p.id + ')">Изменить</button> ' +
            '<button class="small red" onclick="deleteProduct(' + p.id + ')">Скрыть</button></td></tr>';
    });

    return '<div class="box"><h2 style="margin-top:0">' + (editing ? 'Редактирование товара #' + editing.id : 'Новый товар') + '</h2>' +
        '<div class="row"><div><label>Артикул</label><input id="pf-sku" value="' + esc(e.sku) + '"></div>' +
        '<div><label>Название</label><input id="pf-name" value="' + esc(e.name) + '"></div></div>' +
        '<label>Описание</label><input id="pf-desc" value="' + esc(e.description) + '">' +
        '<label>Ссылка на фото (если пусто, берётся файл img/products/АРТИКУЛ.jpg)</label><input id="pf-img" value="' + esc(e.image_url) + '">' +
        '<div class="row"><div><label>Цена</label><input id="pf-price" type="number" value="' + esc(e.price) + '"></div>' +
        '<div><label>Остаток' + (editing ? ' (меняется через поставки и списания)' : '') + '</label><input id="pf-stock" type="number" value="' + e.stock_quantity + '" ' + (editing ? 'disabled' : '') + '></div></div>' +
        '<div class="row"><div><label>Категория</label><select id="pf-cat">' + catOpts + '</select></div>' +
        '<div><label>Бренд</label><select id="pf-brand">' + brandOpts + '</select></div></div>' +
        '<label>Характеристики (по строке, формат ключ=значение; для конфигуратора нужен component=cpu/motherboard/ram/gpu/psu/case/cooler/storage)</label>' +
        '<textarea id="pf-specs" rows="5">' + esc(specText) + '</textarea>' +
        '<button style="margin-top:10px" onclick="saveProduct()">Сохранить</button> ' +
        (editing ? '<button class="gray" style="margin-top:10px" onclick="editing = null; drawTab();">Отмена</button>' : '') + '</div>' +
        '<div class="box wrap"><table><tr><th>ID</th><th>Артикул</th><th>Название</th><th>Цена</th><th>Остаток</th><th></th></tr>' + rows + '</table></div>';
}

async function editProduct(id) {
    editing = await api('GET', '/products/' + id);
    drawTab();
    window.scrollTo(0, 0);
}

async function saveProduct() {
    var specs = {};
    val('pf-specs').split('\n').forEach(function (line) {
        var i = line.indexOf('=');
        if (i > 0) {
            specs[line.slice(0, i).trim()] = line.slice(i + 1).trim();
        }
    });
    var body = {
        sku: val('pf-sku'),
        name: val('pf-name'),
        description: val('pf-desc'),
        price: Number(val('pf-price')),
        category_id: Number(val('pf-cat')),
        brand_id: Number(val('pf-brand')),
        image_url: val('pf-img').trim() === '' ? null : val('pf-img').trim(),
        specs: specs,
        stock_quantity: Number(val('pf-stock')),
        is_active: true
    };
    try {
        if (editing) {
            await api('PUT', '/products/' + editing.id, body);
        } else {
            await api('POST', '/products', body);
        }
        toast('Товар сохранён');
        editing = null;
        drawTab();
    } catch (e) {
        toast(e.message, true);
    }
}

async function deleteProduct(id) {
    if (!confirm('Скрыть товар из каталога?')) {
        return;
    }
    try {
        await api('DELETE', '/products/' + id);
        toast('Товар скрыт');
        drawTab();
    } catch (e) {
        toast(e.message, true);
    }
}

async function tabUsers() {
    var users = await api('GET', '/users');
    var roles = ['customer', 'manager', 'storekeeper', 'admin'];

    var rows = '';
    users.forEach(function (u) {
        var opts = '';
        roles.forEach(function (r) { opts += '<option' + (u.role === r ? ' selected' : '') + '>' + r + '</option>'; });
        var self = u.id === me.id;
        rows += '<tr><td>' + u.id + '</td><td>' + esc(u.email) + '</td><td>' + esc(u.full_name) + '</td>' +
            '<td><select id="ur-' + u.id + '" ' + (self ? 'disabled' : '') + ' onchange="setUserRole(' + u.id + ')">' + opts + '</select></td>' +
            '<td>' + (u.is_active ? '<span class="ok">активен</span>' : '<span class="no">заблокирован</span>') + '</td>' +
            '<td>' + (self ? '' : '<button class="small gray" onclick="toggleUser(' + u.id + ', ' + !u.is_active + ')">' +
                (u.is_active ? 'Заблокировать' : 'Разблокировать') + '</button>') + '</td></tr>';
    });

    var roleOpts = '';
    roles.forEach(function (r) { roleOpts += '<option>' + r + '</option>'; });

    return '<div class="box wrap"><table><tr><th>ID</th><th>Email</th><th>Имя</th><th>Роль</th><th>Статус</th><th></th></tr>' + rows + '</table></div>' +
        '<h2>Создать пользователя</h2><div class="box" style="max-width:460px">' +
        '<label>Email</label><input id="nu-email"><label>Имя</label><input id="nu-name">' +
        '<label>Пароль</label><input id="nu-pass" type="password"><label>Роль</label><select id="nu-role">' + roleOpts + '</select>' +
        '<button class="full" onclick="createUser()">Создать</button></div>';
}

async function setUserRole(id) {
    try {
        await api('PATCH', '/users/' + id + '/role', { role: val('ur-' + id) });
        toast('Роль изменена');
    } catch (e) {
        toast(e.message, true);
    }
    drawTab();
}

async function toggleUser(id, active) {
    try {
        await api('PATCH', '/users/' + id + '/status', { is_active: active });
        toast('Готово');
    } catch (e) {
        toast(e.message, true);
    }
    drawTab();
}

async function createUser() {
    try {
        await api('POST', '/users', { email: val('nu-email'), full_name: val('nu-name'), password: val('nu-pass'), role: val('nu-role') });
        toast('Пользователь создан');
        drawTab();
    } catch (e) {
        toast(e.message, true);
    }
}

async function tabPromo() {
    var list = await api('GET', '/sale');
    var rows = '';
    list.forEach(function (s) {
        rows += '<tr><td>' + esc(s.name) + '</td><td><b>' + esc(s.code) + '</b></td><td>' + s.percent + '%</td>' +
            '<td>' + (s.active ? 'да' : 'нет') + '</td><td><button class="small red" onclick="deletePromo(' + s.id + ')">Удалить</button></td></tr>';
    });
    if (rows === '') {
        rows = '<tr><td colspan="5">Промокодов нет</td></tr>';
    }
    return '<div class="box wrap"><table><tr><th>Название</th><th>Код</th><th>Скидка</th><th>Активен</th><th></th></tr>' + rows + '</table></div>' +
        '<h2>Новый промокод</h2><div class="box" style="max-width:420px">' +
        '<label>Название</label><input id="sl-name"><label>Код</label><input id="sl-code"><label>Скидка, %</label><input id="sl-percent" type="number">' +
        '<button class="full" onclick="addPromo()">Создать</button></div>';
}

async function addPromo() {
    try {
        await api('POST', '/sale', { name: val('sl-name'), code: val('sl-code'), percent: Number(val('sl-percent')), active: true });
        toast('Промокод создан');
        drawTab();
    } catch (e) {
        toast(e.message, true);
    }
}

async function deletePromo(id) {
    await api('DELETE', '/sale/' + id);
    drawTab();
}

var anFrom = '';
var anTo = '';

async function tabAnalytics() {
    var q = '';
    if (anFrom) {
        q += 'date_from=' + anFrom + '&';
    }
    if (anTo) {
        q += 'date_to=' + anTo + '&';
    }
    var sales = await api('GET', '/analytics/sales?' + q);
    var top = await api('GET', '/analytics/top-products?' + q);
    var byCat = await api('GET', '/analytics/revenue-by-category?' + q);

    var topRows = '';
    top.forEach(function (t) {
        topRows += '<tr><td>' + esc(t.name) + '</td><td>' + t.quantity_sold + '</td><td>' + money(t.revenue) + '</td></tr>';
    });
    if (topRows === '') {
        topRows = '<tr><td colspan="3">Продаж нет</td></tr>';
    }
    var catRows = '';
    byCat.forEach(function (c) {
        catRows += '<tr><td>' + esc(c.category_name) + '</td><td>' + money(c.revenue) + '</td></tr>';
    });
    if (catRows === '') {
        catRows = '<tr><td colspan="2">Продаж нет</td></tr>';
    }

    return '<div class="box"><div class="row" style="max-width:520px">' +
        '<div><label>С даты</label><input type="date" id="an-from" value="' + anFrom + '"></div>' +
        '<div><label>По дату</label><input type="date" id="an-to" value="' + anTo + '"></div></div>' +
        '<button class="small" style="margin-top:10px" onclick="anFrom = val(\'an-from\'); anTo = val(\'an-to\'); drawTab();">Показать</button></div>' +
        '<div class="box"><b>Заказов:</b> ' + sales.orders_count + ' · <b>Продано штук:</b> ' + sales.items_sold +
        ' · <b>Выручка:</b> ' + money(sales.revenue) + '</div>' +
        '<h2>Топ товаров</h2><div class="box wrap"><table><tr><th>Товар</th><th>Продано</th><th>Выручка</th></tr>' + topRows + '</table></div>' +
        '<h2>Выручка по категориям</h2><div class="box wrap"><table><tr><th>Категория</th><th>Выручка</th></tr>' + catRows + '</table></div>';
}
