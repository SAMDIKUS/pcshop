var app = document.getElementById('app');
var cats = [];
var brands = [];
var cartPromo = null;

var statusNames = {
    'new': 'Новый',
    'processing': 'В обработке',
    'assembled': 'Собран',
    'shipped': 'Отправлен',
    'delivered': 'Доставлен',
    'cancelled': 'Отменён',
    'approved': 'Одобрена',
    'rejected': 'Отклонена',
    'completed': 'Завершена'
};

var filters = {
    category_id: '', brand_id: '', price_min: '', price_max: '',
    socket: '', ram_type: '', form_factor: '',
    in_stock: false, sort: '', page: 1
};

function esc(s) {
    if (s === null || s === undefined) {
        return '';
    }
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function productImg(p, cls) {
    var custom = p.image_url ? '1' : '';
    var src = p.image_url ? p.image_url : '/img/products/' + p.sku + '.jpg';
    return '<img class="' + cls + '" src="' + esc(src) + '" alt="' + esc(p.name) + '" data-sku="' + esc(p.sku) +
        '" data-custom="' + custom + '" data-try="0" onerror="imgFail(this)">';
}

function imgFail(img) {
    var exts = ['png', 'webp'];
    var n = Number(img.getAttribute('data-try'));
    if (img.getAttribute('data-custom') || n >= exts.length) {
        img.remove();
        return;
    }
    img.setAttribute('data-try', n + 1);
    img.src = '/img/products/' + img.getAttribute('data-sku') + '.' + exts[n];
}

function money(n) {
    return Number(n).toLocaleString('ru-RU') + ' ₽';
}

function fmtDate(s) {
    return new Date(s).toLocaleString('ru-RU');
}

function statusTag(s) {
    return '<span class="status ' + s + '">' + (statusNames[s] || s) + '</span>';
}

function toast(text, bad) {
    var t = document.getElementById('toast');
    t.textContent = text;
    t.className = 'show' + (bad ? ' bad' : '');
    setTimeout(function () { t.className = ''; }, 2600);
}

function val(id) {
    return document.getElementById(id).value;
}

function flattenCats(list, level, result) {
    list.forEach(function (c) {
        result.push({ id: c.id, name: c.name, level: level });
        flattenCats(c.children, level + 1, result);
    });
    return result;
}

function catName(id) {
    var c = cats.find(function (x) { return x.id == id; });
    return c ? c.name : '';
}

function brandName(id) {
    var b = brands.find(function (x) { return x.id == id; });
    return b ? b.name : '';
}

function renderNav() {
    var html = '<a href="#/">Каталог</a><a href="#/config">Конфигуратор</a>';
    if (me && me.role === 'customer') {
        html += '<a href="#/cart">Корзина <span class="badge" id="cartCount">0</span></a>';
        html += '<a href="#/orders">Заказы</a>';
    }
    if (me && me.role !== 'customer') {
        html += '<a href="#/staff">Панель (' + me.role + ')</a>';
    }
    if (me) {
        html += '<a href="#/profile">' + esc(me.full_name || me.email) + '</a>';
        html += '<a href="#" onclick="logout(); return false;">Выйти</a>';
    } else {
        html += '<a href="#/login">Войти</a>';
    }
    document.getElementById('nav').innerHTML = html;
}

async function updateCartCount() {
    var el = document.getElementById('cartCount');
    if (!el || !me || me.role !== 'customer') {
        return;
    }
    try {
        var cart = await api('GET', '/cart');
        var n = 0;
        cart.items.forEach(function (i) { n += i.quantity; });
        el.textContent = n;
    } catch (e) {
    }
}

function logout() {
    clearTokens();
    cartPromo = null;
    renderNav();
    location.hash = '#/';
    toast('Вы вышли');
}

async function pageCatalog() {
    var info = null;
    if (filters.category_id) {
        info = await api('GET', '/categories/' + filters.category_id + '/filters');
    }

    var query = [];
    for (var k in filters) {
        if (filters[k] !== '' && filters[k] !== false) {
            query.push(k + '=' + encodeURIComponent(filters[k]));
        }
    }
    query.push('limit=12');
    var data = await api('GET', '/products?' + query.join('&'));

    var catOptions = '<option value="">Все категории</option>';
    cats.forEach(function (c) {
        var pad = '';
        for (var i = 0; i < c.level; i++) {
            pad += '— ';
        }
        var sel = filters.category_id == c.id ? ' selected' : '';
        catOptions += '<option value="' + c.id + '"' + sel + '>' + pad + esc(c.name) + '</option>';
    });

    var brandList = brands;
    if (info) {
        brandList = info.brands;
    }
    var brandOptions = '<option value="">Все бренды</option>';
    brandList.forEach(function (b) {
        var sel = filters.brand_id == b.id ? ' selected' : '';
        brandOptions += '<option value="' + b.id + '"' + sel + '>' + esc(b.name) + '</option>';
    });

    var specHtml = '';
    var specNames = { socket: 'Сокет', ram_type: 'Тип памяти', form_factor: 'Форм-фактор' };
    for (var key in specNames) {
        if (info && info.specs[key]) {
            var opts = '<option value="">Любой</option>';
            info.specs[key].forEach(function (v) {
                var sel = filters[key] == v ? ' selected' : '';
                opts += '<option' + sel + '>' + esc(v) + '</option>';
            });
            specHtml += '<label>' + specNames[key] + '</label><select id="f-' + key + '">' + opts + '</select>';
        }
    }

    var sorts = [['', 'По умолчанию'], ['price_asc', 'Сначала дешёвые'], ['price_desc', 'Сначала дорогие'],
        ['name', 'По названию'], ['rating', 'По рейтингу']];
    var sortOptions = '';
    sorts.forEach(function (s) {
        sortOptions += '<option value="' + s[0] + '"' + (filters.sort === s[0] ? ' selected' : '') + '>' + s[1] + '</option>';
    });

    var cards = '';
    data.items.forEach(function (p) {
        var stock = p.stock_quantity > 0
            ? '<span class="ok">В наличии: ' + p.stock_quantity + '</span>'
            : '<span class="no">Нет в наличии</span>';
        var rating = p.avg_rating ? p.avg_rating.toFixed(1) + ' ★' : 'нет оценок';
        cards += '<div class="card">' +
            '<div class="pic"><span>' + esc(catName(p.category_id)) + '</span>' + productImg(p, '') + '</div>' +
            '<a class="name" href="#/product/' + p.id + '">' + esc(p.name) + '</a>' +
            '<div class="meta">' + esc(brandName(p.brand_id)) + ' · ' + rating + '</div>' +
            '<div class="meta">' + stock + '</div>' +
            '<div class="price">' + money(p.price) + '</div>' +
            '<button ' + (p.stock_quantity > 0 ? '' : 'disabled') + ' onclick="addToCart(' + p.id + ')">В корзину</button>' +
            '</div>';
    });
    if (cards === '') {
        cards = '<p>Ничего не найдено</p>';
    }

    var pager = '';
    if (data.total_pages > 1) {
        pager = '<div class="pager">' +
            '<button class="gray small" ' + (data.page <= 1 ? 'disabled' : '') + ' onclick="goPage(' + (data.page - 1) + ')">Назад</button>' +
            '<span>Страница ' + data.page + ' из ' + data.total_pages + '</span>' +
            '<button class="gray small" ' + (data.page >= data.total_pages ? 'disabled' : '') + ' onclick="goPage(' + (data.page + 1) + ')">Вперёд</button>' +
            '</div>';
    }

    var priceHint = '';
    if (info && info.price_min !== null) {
        priceHint = '<div class="muted">от ' + info.price_min + ' до ' + info.price_max + '</div>';
    }

    app.innerHTML = '<h1>Каталог</h1>' +
        '<div class="layout">' +
        '<div class="side box">' +
        '<label>Категория</label><select id="f-category">' + catOptions + '</select>' +
        '<label>Бренд</label><select id="f-brand">' + brandOptions + '</select>' +
        specHtml +
        '<label>Цена, ₽</label>' + priceHint +
        '<div class="row"><input id="f-min" type="number" placeholder="от" value="' + esc(filters.price_min) + '">' +
        '<input id="f-max" type="number" placeholder="до" value="' + esc(filters.price_max) + '"></div>' +
        '<div class="check"><input type="checkbox" id="f-stock" ' + (filters.in_stock ? 'checked' : '') + '>Только в наличии</div>' +
        '<label>Сортировка</label><select id="f-sort">' + sortOptions + '</select>' +
        '<button class="full" onclick="applyFilters()">Применить</button>' +
        '<button class="full gray" onclick="resetFilters()">Сбросить</button>' +
        '</div>' +
        '<div class="content"><div class="muted" style="margin-bottom:10px">Найдено товаров: ' + data.total + '</div>' +
        '<div class="grid">' + cards + '</div>' + pager + '</div>' +
        '</div>';
}

function applyFilters() {
    var newCat = val('f-category');
    var catChanged = newCat != filters.category_id;
    filters.category_id = newCat;
    filters.brand_id = val('f-brand');
    filters.price_min = val('f-min');
    filters.price_max = val('f-max');
    filters.in_stock = document.getElementById('f-stock').checked;
    filters.sort = val('f-sort');
    filters.page = 1;
    ['socket', 'ram_type', 'form_factor'].forEach(function (key) {
        var el = document.getElementById('f-' + key);
        if (catChanged || !el) {
            filters[key] = '';
        } else {
            filters[key] = el.value;
        }
    });
    if (catChanged) {
        filters.brand_id = '';
    }
    route();
}

function resetFilters() {
    filters = {
        category_id: '', brand_id: '', price_min: '', price_max: '',
        socket: '', ram_type: '', form_factor: '',
        in_stock: false, sort: '', page: 1
    };
    route();
}

function goPage(n) {
    filters.page = n;
    route();
}

async function addToCart(productId) {
    if (!me) {
        toast('Сначала войдите в аккаунт', true);
        location.hash = '#/login';
        return;
    }
    if (me.role !== 'customer') {
        toast('Корзина только для покупателей', true);
        return;
    }
    try {
        await api('POST', '/cart/items', { product_id: productId, quantity: 1 });
        toast('Добавлено в корзину');
        updateCartCount();
    } catch (e) {
        toast(e.message, true);
    }
}

async function pageProduct(id) {
    var p = await api('GET', '/products/' + id);
    var reviews = await api('GET', '/products/' + id + '/reviews');

    var specRows = '';
    for (var key in p.specs) {
        specRows += '<tr><td>' + esc(key) + '</td><td>' + esc(p.specs[key]) + '</td></tr>';
    }

    var reviewHtml = '';
    reviews.forEach(function (r) {
        reviewHtml += '<div class="review"><b>Покупатель #' + r.user_id + '</b> · ' + r.rating + ' ★ ' +
            '<span class="muted">' + fmtDate(r.created_at) + '</span><div>' + esc(r.text) + '</div></div>';
    });
    if (reviewHtml === '') {
        reviewHtml = '<p class="muted">Отзывов пока нет</p>';
    }

    var form = '';
    if (me && me.role === 'customer') {
        form = '<h2>Оставить отзыв</h2><div class="box" style="max-width:420px">' +
            '<label>Оценка</label><select id="r-rating"><option>5</option><option>4</option><option>3</option><option>2</option><option>1</option></select>' +
            '<label>Текст</label><textarea id="r-text" rows="3"></textarea>' +
            '<button class="full" onclick="sendReview(' + id + ')">Отправить</button>' +
            '<div class="muted" style="margin-top:6px">Отзыв можно оставить только на товар из доставленного заказа</div></div>';
    }

    app.innerHTML = '<p><a href="#/">← В каталог</a></p>' +
        '<div class="box prodtop"><div class="bigpic"><span>' + esc(catName(p.category_id)) + '</span>' + productImg(p, '') + '</div>' +
        '<div class="info"><h1>' + esc(p.name) + '</h1>' +
        '<div class="muted">Артикул: ' + esc(p.sku) + ' · ' + esc(catName(p.category_id)) + ' · ' + esc(brandName(p.brand_id)) + '</div>' +
        '<p>' + esc(p.description) + '</p>' +
        '<div class="price" style="font-size:26px;font-weight:bold">' + money(p.price) + '</div>' +
        '<p>' + (p.stock_quantity > 0 ? '<span class="ok">В наличии: ' + p.stock_quantity + ' шт.</span>' : '<span class="no">Нет в наличии</span>') +
        ' · Рейтинг: ' + (p.avg_rating ? p.avg_rating.toFixed(1) + ' ★' : 'нет оценок') + '</p>' +
        '<button ' + (p.stock_quantity > 0 ? '' : 'disabled') + ' onclick="addToCart(' + p.id + ')">В корзину</button></div></div>' +
        '<h2>Характеристики</h2><div class="box"><table class="specs">' + specRows + '</table></div>' +
        '<h2>Отзывы</h2><div class="box">' + reviewHtml + '</div>' + form;
}

async function sendReview(id) {
    try {
        await api('POST', '/products/' + id + '/reviews', { rating: Number(val('r-rating')), text: val('r-text') });
        toast('Отзыв добавлен');
        route();
    } catch (e) {
        toast(e.message, true);
    }
}

async function pageCart() {
    if (!me || me.role !== 'customer') {
        location.hash = '#/login';
        return;
    }
    var cart = await api('GET', '/cart');
    var payments = await api('GET', '/payment-methods');
    var deliveries = await api('GET', '/delivery-methods');

    if (cart.items.length === 0) {
        app.innerHTML = '<h1>Корзина</h1><div class="box">Корзина пуста. <a href="#/">Перейти в каталог</a></div>';
        return;
    }

    var rows = '';
    cart.items.forEach(function (i) {
        rows += '<tr><td><div class="withthumb"><div class="thumbbox">' + productImg({ sku: i.sku, image_url: i.image_url, name: i.name }, '') + '</div>' +
            '<a href="#/product/' + i.product_id + '">' + esc(i.name) + '</a></div></td>' +
            '<td>' + money(i.price) + '</td>' +
            '<td><input type="number" min="1" id="q-' + i.id + '" value="' + i.quantity + '" onchange="changeQty(' + i.id + ')"></td>' +
            '<td>' + money(i.line_total) + '</td>' +
            '<td><button class="red small" onclick="removeFromCart(' + i.id + ')">Удалить</button></td></tr>';
    });

    var payOptions = '';
    payments.forEach(function (p) { payOptions += '<option value="' + p.id + '">' + esc(p.name) + '</option>'; });
    var delOptions = '';
    deliveries.forEach(function (d) {
        delOptions += '<option value="' + d.id + '" data-price="' + d.price + '">' + esc(d.name) + ' (' + money(d.price) + ')</option>';
    });

    app.innerHTML = '<h1>Корзина</h1>' +
        '<div class="box wrap"><table><tr><th>Товар</th><th>Цена</th><th>Кол-во</th><th>Сумма</th><th></th></tr>' + rows + '</table>' +
        '<div class="total">Товары: ' + money(cart.total) + '</div>' +
        '<button class="gray small" onclick="clearCart()">Очистить корзину</button></div>' +
        '<h2>Оформление заказа</h2><div class="box" style="max-width:480px">' +
        '<label>Способ оплаты</label><select id="o-pay">' + payOptions + '</select>' +
        '<label>Способ доставки</label><select id="o-del" onchange="showTotal(' + cart.total + ')">' + delOptions + '</select>' +
        '<label>Адрес</label><input id="o-address" placeholder="Город, улица, дом">' +
        '<label>Промокод</label>' +
        '<div class="row"><input id="o-promo" placeholder="Если есть" value="' + esc(cartPromo ? cartPromo.code : '') + '">' +
        '<button class="gray" style="flex:none" onclick="applyCartPromo(' + cart.total + ')">Применить</button></div>' +
        '<div class="muted" id="o-promo-info" style="margin-top:6px"></div>' +
        '<div class="total" id="o-total"></div>' +
        '<button class="full green" onclick="makeOrder()">Оформить заказ</button></div>';
    showTotal(cart.total);
}

function showTotal(sum) {
    var sel = document.getElementById('o-del');
    var price = Number(sel.options[sel.selectedIndex].getAttribute('data-price'));
    var discount = 0;
    var info = '';
    if (cartPromo) {
        discount = Math.round(sum * cartPromo.percent) / 100;
        info = 'Промокод ' + cartPromo.code + ': скидка ' + cartPromo.percent + '% (−' + money(discount) + ')';
    }
    document.getElementById('o-promo-info').textContent = info;
    document.getElementById('o-total').textContent = 'Итого: ' + money(sum + price - discount);
}

async function applyCartPromo(sum) {
    var code = val('o-promo').trim();
    if (code === '') {
        cartPromo = null;
        showTotal(sum);
        return;
    }
    try {
        var data = await api('GET', '/cart/promo?code=' + encodeURIComponent(code));
        cartPromo = { code: data.code, percent: data.percent };
        toast('Промокод применён');
    } catch (e) {
        cartPromo = null;
        toast(e.message, true);
    }
    showTotal(sum);
}

async function changeQty(itemId) {
    try {
        await api('PATCH', '/cart/items/' + itemId, { quantity: Number(val('q-' + itemId)) });
        route();
        updateCartCount();
    } catch (e) {
        toast(e.message, true);
        route();
    }
}

async function removeFromCart(itemId) {
    await api('DELETE', '/cart/items/' + itemId);
    route();
    updateCartCount();
}

async function clearCart() {
    await api('DELETE', '/cart');
    route();
    updateCartCount();
}

async function makeOrder() {
    try {
        var order = await api('POST', '/orders', {
            payment_method_id: Number(val('o-pay')),
            delivery_method_id: Number(val('o-del')),
            address: val('o-address'),
            promo_code: cartPromo ? cartPromo.code : undefined
        });
        cartPromo = null;
        toast('Заказ №' + order.id + ' оформлен');
        updateCartCount();
        location.hash = '#/order/' + order.id;
    } catch (e) {
        toast(e.message, true);
    }
}

var orderFilter = '';

async function pageOrders() {
    if (!me) {
        location.hash = '#/login';
        return;
    }
    if (me.role !== 'customer') {
        location.hash = '#/staff';
        return;
    }
    var orders = await api('GET', '/orders' + (orderFilter ? '?status=' + orderFilter : ''));
    var returns = await api('GET', '/returns');

    var opts = '<option value="">Все статусы</option>';
    ['new', 'processing', 'assembled', 'shipped', 'delivered', 'cancelled'].forEach(function (s) {
        opts += '<option value="' + s + '"' + (orderFilter === s ? ' selected' : '') + '>' + statusNames[s] + '</option>';
    });

    var rows = '';
    orders.forEach(function (o) {
        rows += '<tr><td><a href="#/order/' + o.id + '">№' + o.id + '</a></td><td>' + fmtDate(o.created_at) + '</td>' +
            '<td>' + statusTag(o.status) + '</td><td>' + money(o.total) + '</td></tr>';
    });
    if (rows === '') {
        rows = '<tr><td colspan="4">Заказов нет</td></tr>';
    }

    var retRows = '';
    returns.forEach(function (r) {
        retRows += '<tr><td>№' + r.id + '</td><td><a href="#/order/' + r.order_id + '">Заказ №' + r.order_id + '</a></td>' +
            '<td>' + (r.type === 'return' ? 'Возврат' : 'Обмен') + '</td><td>' + esc(r.reason) + '</td><td>' + statusTag(r.status) + '</td></tr>';
    });
    if (retRows === '') {
        retRows = '<tr><td colspan="5">Заявок нет</td></tr>';
    }

    app.innerHTML = '<h1>Мои заказы</h1>' +
        '<div class="box" style="max-width:260px"><label>Статус</label><select onchange="orderFilter = this.value; route();">' + opts + '</select></div>' +
        '<div class="box wrap"><table><tr><th>Заказ</th><th>Дата</th><th>Статус</th><th>Сумма</th></tr>' + rows + '</table></div>' +
        '<h2>Заявки на возврат и обмен</h2>' +
        '<div class="box wrap"><table><tr><th>№</th><th>Заказ</th><th>Тип</th><th>Причина</th><th>Статус</th></tr>' + retRows + '</table></div>';
}

async function pageOrder(id) {
    var order = await api('GET', '/orders/' + id);
    var history = await api('GET', '/orders/' + id + '/status-history');

    var rows = '';
    for (var i = 0; i < order.items.length; i++) {
        var item = order.items[i];
        var name = 'Товар #' + item.product_id;
        try {
            var p = await api('GET', '/products/' + item.product_id);
            name = p.name;
        } catch (e) {
        }
        var action = '';
        if (order.status === 'delivered' && me.role === 'customer') {
            action = '<select id="rt-' + item.id + '"><option value="return">Возврат</option><option value="exchange">Обмен</option></select> ' +
                '<input id="rr-' + item.id + '" placeholder="Причина" style="width:150px"> ' +
                '<button class="small gray" onclick="sendReturn(' + item.id + ')">Подать заявку</button>';
        }
        rows += '<tr><td><a href="#/product/' + item.product_id + '">' + esc(name) + '</a></td><td>' + item.quantity + '</td>' +
            '<td>' + money(item.price) + '</td><td>' + action + '</td></tr>';
    }

    var histHtml = '';
    history.forEach(function (h) {
        histHtml += '<div>' + fmtDate(h.changed_at) + ' — ' + statusTag(h.status) + '</div>';
    });

    var cancelBtn = '';
    if (['new', 'processing', 'assembled'].indexOf(order.status) !== -1) {
        cancelBtn = '<button class="red" onclick="cancelOrder(' + id + ')">Отменить заказ</button>';
    }

    var discount = '';
    if (Number(order.discount) > 0) {
        discount = '<div>Скидка: −' + money(order.discount) + (order.promo_code ? ' (' + esc(order.promo_code) + ')' : '') + '</div>';
    }

    app.innerHTML = '<p><a href="#/orders">← К заказам</a></p>' +
        '<div class="box"><h1>Заказ №' + order.id + ' ' + statusTag(order.status) + '</h1>' +
        '<div class="muted">' + fmtDate(order.created_at) + '</div>' +
        '<p>Адрес: ' + esc(order.address) + '</p>' + discount +
        '<div class="total" style="text-align:left">Итого: ' + money(order.total) + '</div>' + cancelBtn + '</div>' +
        '<h2>Состав</h2><div class="box wrap"><table><tr><th>Товар</th><th>Кол-во</th><th>Цена</th><th></th></tr>' + rows + '</table></div>' +
        '<h2>История статусов</h2><div class="box">' + histHtml + '</div>';
}

async function cancelOrder(id) {
    if (!confirm('Отменить заказ?')) {
        return;
    }
    try {
        await api('POST', '/orders/' + id + '/cancel');
        toast('Заказ отменён');
        route();
    } catch (e) {
        toast(e.message, true);
    }
}

async function sendReturn(itemId) {
    try {
        await api('POST', '/returns', {
            order_item_id: itemId,
            type: val('rt-' + itemId),
            reason: val('rr-' + itemId)
        });
        toast('Заявка отправлена');
    } catch (e) {
        toast(e.message, true);
    }
}

function pageLogin() {
    app.innerHTML = '<div class="box center-form"><h1>Вход</h1>' +
        '<label>Email</label><input id="l-email" value="user@shop.ru">' +
        '<label>Пароль</label><input id="l-pass" type="password" value="user123">' +
        '<button class="full" onclick="doLogin()">Войти</button>' +
        '<p>Нет аккаунта? <a href="#/register">Регистрация</a></p>' +
        '<div class="muted">Тестовые: admin@shop.ru / admin123, manager@shop.ru / manager123, store@shop.ru / store123</div></div>';
}

async function doLogin() {
    try {
        var data = await api('POST', '/auth/login', { email: val('l-email'), password: val('l-pass') });
        saveTokens(data.access_token, data.refresh_token);
        await loadMe();
        renderNav();
        updateCartCount();
        toast('Добро пожаловать!');
        if (me.role === 'customer') {
            location.hash = '#/';
        } else {
            location.hash = '#/staff';
        }
    } catch (e) {
        toast(e.message, true);
    }
}

function pageRegister() {
    app.innerHTML = '<div class="box center-form"><h1>Регистрация</h1>' +
        '<label>Имя</label><input id="g-name">' +
        '<label>Email</label><input id="g-email">' +
        '<label>Телефон</label><input id="g-phone">' +
        '<label>Пароль (от 6 символов)</label><input id="g-pass" type="password">' +
        '<button class="full" onclick="doRegister()">Зарегистрироваться</button>' +
        '<p>Уже есть аккаунт? <a href="#/login">Войти</a></p></div>';
}

async function doRegister() {
    try {
        await api('POST', '/auth/register', {
            full_name: val('g-name'), email: val('g-email'), phone: val('g-phone'), password: val('g-pass')
        });
        var data = await api('POST', '/auth/login', { email: val('g-email'), password: val('g-pass') });
        saveTokens(data.access_token, data.refresh_token);
        await loadMe();
        renderNav();
        updateCartCount();
        toast('Аккаунт создан');
        location.hash = '#/';
    } catch (e) {
        toast(e.message, true);
    }
}

async function pageProfile() {
    if (!me) {
        location.hash = '#/login';
        return;
    }
    app.innerHTML = '<div class="box center-form"><h1>Профиль</h1>' +
        '<div class="muted">' + esc(me.email) + ' · роль: ' + me.role + '</div>' +
        '<label>Имя</label><input id="p-name" value="' + esc(me.full_name) + '">' +
        '<label>Телефон</label><input id="p-phone" value="' + esc(me.phone) + '">' +
        '<label>Новый пароль (если нужно сменить)</label><input id="p-pass" type="password">' +
        '<button class="full" onclick="saveProfile()">Сохранить</button></div>';
}

async function saveProfile() {
    var body = { full_name: val('p-name'), phone: val('p-phone') };
    if (val('p-pass') !== '') {
        body.password = val('p-pass');
    }
    try {
        me = await api('PATCH', '/users/me', body);
        renderNav();
        toast('Сохранено');
    } catch (e) {
        toast(e.message, true);
    }
}
