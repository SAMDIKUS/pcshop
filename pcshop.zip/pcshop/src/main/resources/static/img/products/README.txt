Сюда кладём фотографии товаров.

Имя файла = артикул товара + расширение (.jpg, .png или .webp), например CPU-001.jpg.
Сайт сам берёт файл по артикулу. Если файла нет, показывается серая заглушка с названием категории.
Для товаров, добавленных через админку, можно вместо файла указать ссылку на фото в поле "Ссылка на фото".

Артикул    Что искать
CPU-001    Intel Core i5-13400F
CPU-002    Intel Core i7-13700K
CPU-003    AMD Ryzen 5 7600
COOL-001   DeepCool AK400
COOL-002   Noctua NH-U12S
COOL-003   Arctic Freezer 36
MB-001     ASUS PRIME B760M-A D4
MB-002     MSI MAG B650 TOMAHAWK
MB-003     Gigabyte Z790 AORUS ELITE
RAM-001    Kingston FURY Beast 16GB DDR4
RAM-002    Corsair Vengeance 32GB DDR5
SSD-001    Samsung 980 PRO 1TB
SSD-002    Kingston NV2 500GB
SSD-003    WD Blue SN580 1TB
SSD-004    Crucial MX500 1TB
HDD-001    Seagate Barracuda 2TB
GPU-001    MSI GeForce RTX 4060 Ventus
GPU-002    ASUS GeForce RTX 4070 Super
PSU-001    Corsair CV550 550W
PSU-002    Corsair RM750e 750W
CASE-001   Corsair 4000D Airflow
CASE-002   Deepcool MACUBE 110
