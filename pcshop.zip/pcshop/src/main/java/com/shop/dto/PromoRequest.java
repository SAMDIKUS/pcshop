package com.shop.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class PromoRequest {
    private String promoCode;
    private BigDecimal discount;
}
