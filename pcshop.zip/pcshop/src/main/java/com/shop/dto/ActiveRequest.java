package com.shop.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ActiveRequest {
    @JsonProperty("is_active")
    private boolean active;
}
