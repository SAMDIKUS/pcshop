package com.shop.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class SupplyItemRequest {
    private Long productId;
    private int quantity;
    private BigDecimal purchasePrice;
}
