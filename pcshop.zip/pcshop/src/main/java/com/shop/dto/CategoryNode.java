package com.shop.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class CategoryNode {
    private Long id;
    private String name;
    private Long parentId;
    private List<CategoryNode> children = new ArrayList<>();
}
