package com.shop.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class CheckRequest {
    private List<Long> productIds = new ArrayList<>();
}
