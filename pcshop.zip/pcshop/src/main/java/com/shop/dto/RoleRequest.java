package com.shop.dto;

import com.shop.entity.Role;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoleRequest {
    private Role role;
}
