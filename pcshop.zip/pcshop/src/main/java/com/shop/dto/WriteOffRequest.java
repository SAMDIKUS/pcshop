package com.shop.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WriteOffRequest {
    private Long productId;
    private int quantity;
    private String reason;
}
