package com.shop.dto;

import com.shop.entity.ReturnStatus;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReturnDecisionRequest {
    private ReturnStatus status;
}
