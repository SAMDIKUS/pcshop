package com.shop.dto;

import com.shop.entity.Role;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserCreateRequest {
    private String email;
    private String password;
    private String fullName;
    private String phone;
    private Role role;
}
