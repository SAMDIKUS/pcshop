package com.shop.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderRequest {
    private Long paymentMethodId;
    private Long deliveryMethodId;
    private String address;
    private String promoCode;
}
