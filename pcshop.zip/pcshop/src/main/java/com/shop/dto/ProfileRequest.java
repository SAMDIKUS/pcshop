package com.shop.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProfileRequest {
    private String fullName;
    private String phone;
    private String password;
}
