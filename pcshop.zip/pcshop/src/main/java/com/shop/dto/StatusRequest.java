package com.shop.dto;

import com.shop.entity.OrderStatus;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StatusRequest {
    private OrderStatus status;
}
