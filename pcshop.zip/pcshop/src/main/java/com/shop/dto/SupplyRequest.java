package com.shop.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class SupplyRequest {
    private Long supplierId;
    private List<SupplyItemRequest> items = new ArrayList<>();
}
