package com.shop.dto;

import com.shop.entity.ReturnType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReturnCreateRequest {
    private Long orderItemId;
    private ReturnType type;
    private String reason;
}
