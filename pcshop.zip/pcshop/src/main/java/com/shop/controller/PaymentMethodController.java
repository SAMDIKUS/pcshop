package com.shop.controller;

import com.shop.entity.PaymentMethod;
import com.shop.repository.PaymentMethodRepository;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/payment-methods")
public class PaymentMethodController {

    private final PaymentMethodRepository paymentRepository;

    public PaymentMethodController(PaymentMethodRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    @GetMapping
    public List<PaymentMethod> list() {
        return paymentRepository.findByActiveTrue();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public PaymentMethod create(@RequestBody PaymentMethod body) {
        if (body.getName() == null || body.getName().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Не указано название");
        }
        body.setId(null);
        return paymentRepository.save(body);
    }

    @PutMapping("/{id}")
    public PaymentMethod replace(@PathVariable Long id, @RequestBody PaymentMethod body) {
        PaymentMethod m = paymentRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Способ оплаты не найден"));
        if (body.getName() == null || body.getName().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Не указано название");
        }
        m.setName(body.getName());
        m.setActive(body.isActive());
        return paymentRepository.save(m);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        PaymentMethod m = paymentRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Способ оплаты не найден"));
        m.setActive(false);
        paymentRepository.save(m);
    }
}
