package com.shop.controller;

import com.shop.entity.DeliveryMethod;
import com.shop.repository.DeliveryMethodRepository;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/delivery-methods")
public class DeliveryMethodController {

    private final DeliveryMethodRepository deliveryRepository;

    public DeliveryMethodController(DeliveryMethodRepository deliveryRepository) {
        this.deliveryRepository = deliveryRepository;
    }

    @GetMapping
    public List<DeliveryMethod> list() {
        return deliveryRepository.findByActiveTrue();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public DeliveryMethod create(@RequestBody DeliveryMethod body) {
        check(body);
        body.setId(null);
        return deliveryRepository.save(body);
    }

    @PutMapping("/{id}")
    public DeliveryMethod replace(@PathVariable Long id, @RequestBody DeliveryMethod body) {
        DeliveryMethod m = deliveryRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Способ доставки не найден"));
        check(body);
        m.setName(body.getName());
        m.setPrice(body.getPrice());
        m.setActive(body.isActive());
        return deliveryRepository.save(m);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        DeliveryMethod m = deliveryRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Способ доставки не найден"));
        m.setActive(false);
        deliveryRepository.save(m);
    }

    private void check(DeliveryMethod body) {
        if (body.getName() == null || body.getName().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Не указано название");
        }
        if (body.getPrice() == null || body.getPrice().compareTo(BigDecimal.ZERO) < 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Неверная цена доставки");
        }
    }
}
