package com.shop.controller;

import com.shop.dto.SupplyRequest;
import com.shop.dto.WriteOffRequest;
import com.shop.entity.Product;
import com.shop.entity.StockMovement;
import com.shop.entity.Supplier;
import com.shop.entity.Supply;
import com.shop.repository.*;
import com.shop.service.StockService;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
public class StockController {

    private final ProductRepository productRepository;
    private final StockMovementRepository movementRepository;
    private final SupplyRepository supplyRepository;
    private final SupplierRepository supplierRepository;
    private final StockService stockService;

    public StockController(ProductRepository productRepository, StockMovementRepository movementRepository,
                           SupplyRepository supplyRepository, SupplierRepository supplierRepository,
                           StockService stockService) {
        this.productRepository = productRepository;
        this.movementRepository = movementRepository;
        this.supplyRepository = supplyRepository;
        this.supplierRepository = supplierRepository;
        this.stockService = stockService;
    }

    private Map<String, Object> row(Product p) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("product_id", p.getId());
        m.put("sku", p.getSku());
        m.put("name", p.getName());
        m.put("stock_quantity", p.getStockQuantity());
        m.put("is_active", p.isActive());
        return m;
    }

    @GetMapping("/stock")
    public List<Map<String, Object>> stock() {
        List<Map<String, Object>> result = new ArrayList<>();
        for (Product p : productRepository.findAll()) {
            result.add(row(p));
        }
        return result;
    }

    @GetMapping("/stock/low")
    public List<Map<String, Object>> low(@RequestParam(name = "threshold", defaultValue = "5") int threshold) {
        List<Map<String, Object>> result = new ArrayList<>();
        for (Product p : productRepository.findByStockQuantityLessThanEqual(threshold)) {
            if (p.isActive()) {
                result.add(row(p));
            }
        }
        return result;
    }

    @GetMapping("/stock/movements")
    public List<StockMovement> movements(@RequestParam(name = "product_id", required = false) Long productId) {
        if (productId != null) {
            return movementRepository.findByProductIdOrderByCreatedAtDesc(productId);
        }
        return movementRepository.findAll(Sort.by(Sort.Direction.DESC, "createdAt"));
    }

    @GetMapping("/stock/{productId}")
    public Map<String, Object> one(@PathVariable Long productId) {
        Product p = productRepository.findById(productId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Товар не найден"));
        Map<String, Object> result = row(p);
        result.put("movements", movementRepository.findByProductIdOrderByCreatedAtDesc(productId));
        return result;
    }

    @PostMapping("/stock/write-offs")
    @ResponseStatus(HttpStatus.CREATED)
    public StockMovement writeOff(@RequestBody WriteOffRequest req) {
        return stockService.writeOff(req);
    }

    @PostMapping("/supplies")
    @ResponseStatus(HttpStatus.CREATED)
    public Supply addSupply(@RequestBody SupplyRequest req) {
        return stockService.addSupply(req);
    }

    @GetMapping("/supplies")
    public List<Supply> supplies() {
        return supplyRepository.findAll(Sort.by(Sort.Direction.DESC, "date"));
    }

    @GetMapping("/suppliers")
    public List<Supplier> suppliers() {
        return supplierRepository.findAll();
    }

    @PostMapping("/suppliers")
    @ResponseStatus(HttpStatus.CREATED)
    public Supplier addSupplier(@RequestBody Supplier body) {
        if (body.getName() == null || body.getName().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Не указано название поставщика");
        }
        body.setId(null);
        return supplierRepository.save(body);
    }
}
