package com.shop.controller;

import com.shop.dto.CheckRequest;
import com.shop.dto.ConfigRequest;
import com.shop.entity.Configuration;
import com.shop.entity.Product;
import com.shop.entity.User;
import com.shop.repository.ConfigurationRepository;
import com.shop.service.CartService;
import com.shop.service.ConfiguratorService;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
public class ConfiguratorController {

    private final ConfiguratorService configuratorService;
    private final ConfigurationRepository configurationRepository;
    private final CartService cartService;

    public ConfiguratorController(ConfiguratorService configuratorService,
                                  ConfigurationRepository configurationRepository,
                                  CartService cartService) {
        this.configuratorService = configuratorService;
        this.configurationRepository = configurationRepository;
        this.cartService = cartService;
    }

    @PostMapping("/configurator/check")
    public Map<String, Object> check(@RequestBody CheckRequest req) {
        return configuratorService.check(req.getProductIds());
    }

    @GetMapping("/configurator/compatible-products")
    public List<Product> compatible(@RequestParam(name = "base_product_id") Long baseProductId,
                                    @RequestParam(name = "category_id") Long categoryId) {
        return configuratorService.compatible(baseProductId, categoryId);
    }

    @PostMapping("/configurations")
    @ResponseStatus(HttpStatus.CREATED)
    public Configuration save(@AuthenticationPrincipal User user, @RequestBody ConfigRequest req) {
        configuratorService.loadProducts(req.getProductIds());

        Configuration c = new Configuration();
        c.setUserId(user.getId());
        if (req.getName() == null || req.getName().isBlank()) {
            c.setName("Моя сборка");
        } else {
            c.setName(req.getName());
        }
        c.setProductIds(new ArrayList<>(req.getProductIds()));
        return configurationRepository.save(c);
    }

    @GetMapping("/configurations")
    public List<Configuration> mine(@AuthenticationPrincipal User user) {
        return configurationRepository.findByUserId(user.getId());
    }

    @PostMapping("/configurations/{id}/to-cart")
    @Transactional
    public Map<String, Object> toCart(@AuthenticationPrincipal User user, @PathVariable Long id) {
        Configuration c = configurationRepository.findById(id).orElse(null);
        if (c == null || !c.getUserId().equals(user.getId())) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Сборка не найдена");
        }
        for (Long productId : c.getProductIds()) {
            cartService.add(user.getId(), productId, 1);
        }
        return cartService.view(user.getId());
    }
}
