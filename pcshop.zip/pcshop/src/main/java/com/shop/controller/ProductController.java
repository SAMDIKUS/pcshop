package com.shop.controller;

import com.shop.dto.ProductPatch;
import com.shop.entity.Product;
import com.shop.repository.BrandRepository;
import com.shop.repository.CategoryRepository;
import com.shop.repository.ProductRepository;
import com.shop.service.ProductService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/products")
public class ProductController {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;
    private final BrandRepository brandRepository;
    private final ProductService productService;

    public ProductController(ProductRepository productRepository, CategoryRepository categoryRepository,
                             BrandRepository brandRepository, ProductService productService) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
        this.brandRepository = brandRepository;
        this.productService = productService;
    }

    @GetMapping
    public Map<String, Object> list(@RequestParam(name = "category_id", required = false) Long categoryId,
                                    @RequestParam(name = "brand_id", required = false) Long brandId,
                                    @RequestParam(name = "price_min", required = false) BigDecimal priceMin,
                                    @RequestParam(name = "price_max", required = false) BigDecimal priceMax,
                                    @RequestParam(name = "socket", required = false) String socket,
                                    @RequestParam(name = "ram_type", required = false) String ramType,
                                    @RequestParam(name = "form_factor", required = false) String formFactor,
                                    @RequestParam(name = "in_stock", required = false) Boolean inStock,
                                    @RequestParam(name = "sort", required = false) String sort,
                                    @RequestParam(name = "page", defaultValue = "1") int page,
                                    @RequestParam(name = "limit", defaultValue = "20") int limit) {
        return productService.search(categoryId, brandId, priceMin, priceMax, socket, ramType,
                formFactor, inStock, sort, page, limit);
    }

    @GetMapping("/{id}")
    public Product getOne(@PathVariable Long id) {
        Product product = productRepository.findById(id).orElse(null);
        if (product == null || !product.isActive()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Товар не найден");
        }
        return product;
    }

    private void check(Product p) {
        if (p.getSku() == null || p.getSku().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Не указан артикул");
        }
        if (p.getName() == null || p.getName().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Не указано название");
        }
        if (p.getPrice() == null || p.getPrice().signum() <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Цена должна быть больше нуля");
        }
        if (p.getStockQuantity() < 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Остаток не может быть отрицательным");
        }
        if (p.getCategoryId() == null || !categoryRepository.existsById(p.getCategoryId())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Категория не найдена");
        }
        if (p.getBrandId() == null || !brandRepository.existsById(p.getBrandId())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Бренд не найден");
        }
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Product create(@RequestBody Product body) {
        check(body);
        if (productRepository.existsBySku(body.getSku())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Товар с таким артикулом уже есть");
        }
        body.setId(null);
        body.setAvgRating(0);
        return productRepository.save(body);
    }

    @PutMapping("/{id}")
    public Product replace(@PathVariable Long id, @RequestBody Product body) {
        Product old = productRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Товар не найден"));
        check(body);
        if (!old.getSku().equals(body.getSku()) && productRepository.existsBySku(body.getSku())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Товар с таким артикулом уже есть");
        }

        old.setSku(body.getSku());
        old.setName(body.getName());
        old.setDescription(body.getDescription());
        old.setPrice(body.getPrice());
        old.setCategoryId(body.getCategoryId());
        old.setBrandId(body.getBrandId());
        old.setImageUrl(body.getImageUrl());
        old.setSpecs(new HashMap<>(body.getSpecs()));
        old.setStockQuantity(body.getStockQuantity());
        old.setActive(body.isActive());
        return productRepository.save(old);
    }

    @PatchMapping("/{id}")
    public Product update(@PathVariable Long id, @RequestBody ProductPatch patch) {
        Product p = productRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Товар не найден"));

        if (patch.getSku() != null) {
            if (!patch.getSku().equals(p.getSku()) && productRepository.existsBySku(patch.getSku())) {
                throw new ResponseStatusException(HttpStatus.CONFLICT, "Товар с таким артикулом уже есть");
            }
            p.setSku(patch.getSku());
        }
        if (patch.getName() != null) {
            p.setName(patch.getName());
        }
        if (patch.getDescription() != null) {
            p.setDescription(patch.getDescription());
        }
        if (patch.getPrice() != null) {
            if (patch.getPrice().signum() <= 0) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Цена должна быть больше нуля");
            }
            p.setPrice(patch.getPrice());
        }
        if (patch.getCategoryId() != null) {
            if (!categoryRepository.existsById(patch.getCategoryId())) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Категория не найдена");
            }
            p.setCategoryId(patch.getCategoryId());
        }
        if (patch.getBrandId() != null) {
            if (!brandRepository.existsById(patch.getBrandId())) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Бренд не найден");
            }
            p.setBrandId(patch.getBrandId());
        }
        if (patch.getImageUrl() != null) {
            p.setImageUrl(patch.getImageUrl());
        }
        if (patch.getSpecs() != null) {
            p.getSpecs().putAll(patch.getSpecs());
        }
        if (patch.getActive() != null) {
            p.setActive(patch.getActive());
        }
        return productRepository.save(p);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        Product p = productRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Товар не найден"));
        p.setActive(false);
        productRepository.save(p);
    }
}
