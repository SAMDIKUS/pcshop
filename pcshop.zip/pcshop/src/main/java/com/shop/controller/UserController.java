package com.shop.controller;

import com.shop.dto.ActiveRequest;
import com.shop.dto.ProfileRequest;
import com.shop.dto.RoleRequest;
import com.shop.dto.UserCreateRequest;
import com.shop.entity.Role;
import com.shop.entity.User;
import com.shop.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/me")
    public User me(@AuthenticationPrincipal User current) {
        return userRepository.findById(current.getId()).get();
    }

    @PatchMapping("/me")
    public User updateMe(@AuthenticationPrincipal User current, @RequestBody ProfileRequest req) {
        User user = userRepository.findById(current.getId()).get();
        if (req.getFullName() != null) {
            if (req.getFullName().isBlank()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Имя не может быть пустым");
            }
            user.setFullName(req.getFullName());
        }
        if (req.getPhone() != null) {
            user.setPhone(req.getPhone());
        }
        if (req.getPassword() != null) {
            if (req.getPassword().length() < 6) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Пароль должен быть не короче 6 символов");
            }
            user.setPassword(passwordEncoder.encode(req.getPassword()));
        }
        return userRepository.save(user);
    }

    @GetMapping
    public List<User> list(@RequestParam(required = false) Role role) {
        if (role != null) {
            return userRepository.findByRole(role);
        }
        return userRepository.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public User create(@RequestBody UserCreateRequest req) {
        if (req.getEmail() == null || !req.getEmail().contains("@")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Неверный email");
        }
        if (req.getPassword() == null || req.getPassword().length() < 6) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Пароль должен быть не короче 6 символов");
        }
        if (req.getRole() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Не указана роль");
        }
        String email = req.getEmail().trim().toLowerCase();
        if (userRepository.existsByEmail(email)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Пользователь с таким email уже есть");
        }

        User user = new User();
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(req.getPassword()));
        user.setFullName(req.getFullName());
        user.setPhone(req.getPhone());
        user.setRole(req.getRole());
        return userRepository.save(user);
    }

    @PatchMapping("/{id}/role")
    public User setRole(@PathVariable Long id, @RequestBody RoleRequest req,
                        @AuthenticationPrincipal User current) {
        if (req.getRole() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Не указана роль");
        }
        if (id.equals(current.getId())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Нельзя менять роль самому себе");
        }
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Пользователь не найден"));
        user.setRole(req.getRole());
        return userRepository.save(user);
    }

    @PatchMapping("/{id}/status")
    public User setStatus(@PathVariable Long id, @RequestBody ActiveRequest req,
                          @AuthenticationPrincipal User current) {
        if (id.equals(current.getId())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Нельзя заблокировать самого себя");
        }
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Пользователь не найден"));
        user.setActive(req.isActive());
        return userRepository.save(user);
    }
}
