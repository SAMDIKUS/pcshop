package com.shop.controller;

import com.shop.dto.LoginRequest;
import com.shop.dto.RefreshRequest;
import com.shop.dto.RegisterRequest;
import com.shop.dto.TokenResponse;
import com.shop.entity.Role;
import com.shop.entity.User;
import com.shop.repository.UserRepository;
import com.shop.security.JwtService;
import io.jsonwebtoken.Claims;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthController(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtService jwtService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public User register(@RequestBody RegisterRequest req) {
        if (req.getEmail() == null || !req.getEmail().contains("@") || !req.getEmail().contains(".")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Неверный email");
        }
        if (req.getPassword() == null || req.getPassword().length() < 6) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Пароль должен быть не короче 6 символов");
        }
        if (req.getFullName() == null || req.getFullName().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Укажите имя");
        }

        String email = req.getEmail().trim().toLowerCase();
        if (userRepository.existsByEmail(email)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Пользователь с таким email уже есть");
        }

        User user = new User();
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(req.getPassword()));
        user.setFullName(req.getFullName());
        user.setPhone(req.getPhone());
        user.setRole(Role.customer);
        return userRepository.save(user);
    }

    @PostMapping("/login")
    public TokenResponse login(@RequestBody LoginRequest req) {
        if (req.getEmail() == null || req.getPassword() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Введите email и пароль");
        }
        User user = userRepository.findByEmail(req.getEmail().trim().toLowerCase()).orElse(null);
        if (user == null || !passwordEncoder.matches(req.getPassword(), user.getPassword())) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Неверный email или пароль");
        }
        if (!user.isActive()) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Аккаунт заблокирован");
        }
        return new TokenResponse(jwtService.makeAccessToken(user), jwtService.makeRefreshToken(user));
    }

    @PostMapping("/refresh")
    public TokenResponse refresh(@RequestBody RefreshRequest req) {
        if (req.getRefreshToken() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Нет refresh токена");
        }
        Claims claims;
        try {
            claims = jwtService.parse(req.getRefreshToken());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Токен недействителен");
        }
        if (!"refresh".equals(claims.get("type", String.class))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Это не refresh токен");
        }
        User user = userRepository.findByEmail(claims.getSubject()).orElse(null);
        if (user == null || !user.isActive()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Пользователь недоступен");
        }
        return new TokenResponse(jwtService.makeAccessToken(user), jwtService.makeRefreshToken(user));
    }
}
