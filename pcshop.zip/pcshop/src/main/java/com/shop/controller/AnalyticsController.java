package com.shop.controller;

import com.shop.entity.*;
import com.shop.repository.CategoryRepository;
import com.shop.repository.OrderRepository;
import com.shop.repository.ProductRepository;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

@RestController
@RequestMapping("/analytics")
public class AnalyticsController {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    public AnalyticsController(OrderRepository orderRepository, ProductRepository productRepository,
                               CategoryRepository categoryRepository) {
        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
    }

    private List<ShopOrder> validOrders(LocalDate from, LocalDate to) {
        if (from == null) {
            from = LocalDate.of(2000, 1, 1);
        }
        if (to == null) {
            to = LocalDate.now();
        }
        List<ShopOrder> result = new ArrayList<>();
        for (ShopOrder o : orderRepository.findByCreatedAtBetween(from.atStartOfDay(), to.atTime(LocalTime.MAX))) {
            if (o.getStatus() != OrderStatus.cancelled) {
                result.add(o);
            }
        }
        return result;
    }

    @GetMapping("/sales")
    public Map<String, Object> sales(@RequestParam(name = "date_from", required = false)
                                     @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFrom,
                                     @RequestParam(name = "date_to", required = false)
                                     @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateTo) {
        List<ShopOrder> orders = validOrders(dateFrom, dateTo);

        BigDecimal revenue = BigDecimal.ZERO;
        int itemsSold = 0;
        for (ShopOrder o : orders) {
            revenue = revenue.add(o.getTotal());
            for (OrderItem item : o.getItems()) {
                itemsSold = itemsSold + item.getQuantity();
            }
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("date_from", dateFrom);
        result.put("date_to", dateTo);
        result.put("orders_count", orders.size());
        result.put("items_sold", itemsSold);
        result.put("revenue", revenue);
        return result;
    }

    @GetMapping("/top-products")
    public List<Map<String, Object>> topProducts(@RequestParam(name = "limit", defaultValue = "10") int limit,
                                                 @RequestParam(name = "date_from", required = false)
                                                 @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFrom,
                                                 @RequestParam(name = "date_to", required = false)
                                                 @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateTo) {
        Map<Long, Integer> quantities = new HashMap<>();
        Map<Long, BigDecimal> revenues = new HashMap<>();

        for (ShopOrder o : validOrders(dateFrom, dateTo)) {
            for (OrderItem item : o.getItems()) {
                Long id = item.getProductId();
                quantities.put(id, quantities.getOrDefault(id, 0) + item.getQuantity());
                BigDecimal line = item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity()));
                revenues.put(id, revenues.getOrDefault(id, BigDecimal.ZERO).add(line));
            }
        }

        List<Long> ids = new ArrayList<>(quantities.keySet());
        ids.sort((a, b) -> quantities.get(b) - quantities.get(a));

        List<Map<String, Object>> result = new ArrayList<>();
        for (Long id : ids) {
            if (result.size() >= limit) {
                break;
            }
            Product p = productRepository.findById(id).orElse(null);
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("product_id", id);
            if (p != null) {
                row.put("name", p.getName());
            } else {
                row.put("name", "удалён");
            }
            row.put("quantity_sold", quantities.get(id));
            row.put("revenue", revenues.get(id));
            result.add(row);
        }
        return result;
    }

    @GetMapping("/revenue-by-category")
    public List<Map<String, Object>> revenueByCategory(@RequestParam(name = "date_from", required = false)
                                                       @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFrom,
                                                       @RequestParam(name = "date_to", required = false)
                                                       @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateTo) {
        Map<Long, BigDecimal> byCategory = new LinkedHashMap<>();

        for (ShopOrder o : validOrders(dateFrom, dateTo)) {
            for (OrderItem item : o.getItems()) {
                Product p = productRepository.findById(item.getProductId()).orElse(null);
                if (p == null) {
                    continue;
                }
                BigDecimal line = item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity()));
                byCategory.put(p.getCategoryId(), byCategory.getOrDefault(p.getCategoryId(), BigDecimal.ZERO).add(line));
            }
        }

        List<Map<String, Object>> result = new ArrayList<>();
        for (Map.Entry<Long, BigDecimal> e : byCategory.entrySet()) {
            Category c = categoryRepository.findById(e.getKey()).orElse(null);
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("category_id", e.getKey());
            if (c != null) {
                row.put("category_name", c.getName());
            } else {
                row.put("category_name", "удалена");
            }
            row.put("revenue", e.getValue());
            result.add(row);
        }
        return result;
    }
}
