package com.shop.controller;

import com.shop.dto.ReviewRequest;
import com.shop.entity.*;
import com.shop.repository.OrderRepository;
import com.shop.repository.ProductRepository;
import com.shop.repository.ReviewRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
public class ReviewController {

    private final ReviewRepository reviewRepository;
    private final ProductRepository productRepository;
    private final OrderRepository orderRepository;

    public ReviewController(ReviewRepository reviewRepository, ProductRepository productRepository,
                            OrderRepository orderRepository) {
        this.reviewRepository = reviewRepository;
        this.productRepository = productRepository;
        this.orderRepository = orderRepository;
    }

    private void updateRating(Long productId) {
        List<Review> reviews = reviewRepository.findByProductId(productId);
        double sum = 0;
        for (Review r : reviews) {
            sum = sum + r.getRating();
        }
        double avg = 0;
        if (!reviews.isEmpty()) {
            avg = Math.round(sum / reviews.size() * 10) / 10.0;
        }
        Product product = productRepository.findById(productId).get();
        product.setAvgRating(avg);
        productRepository.save(product);
    }

    private boolean hasBought(Long userId, Long productId) {
        for (ShopOrder o : orderRepository.findByUserId(userId)) {
            if (o.getStatus() != OrderStatus.delivered) {
                continue;
            }
            for (OrderItem item : o.getItems()) {
                if (item.getProductId().equals(productId)) {
                    return true;
                }
            }
        }
        return false;
    }

    @GetMapping("/products/{id}/reviews")
    public List<Review> list(@PathVariable Long id) {
        if (!productRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Товар не найден");
        }
        return reviewRepository.findByProductId(id);
    }

    @PostMapping("/products/{id}/reviews")
    @ResponseStatus(HttpStatus.CREATED)
    public Review add(@AuthenticationPrincipal User user, @PathVariable Long id, @RequestBody ReviewRequest req) {
        if (!productRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Товар не найден");
        }
        if (req.getRating() == null || req.getRating() < 1 || req.getRating() > 5) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Оценка должна быть от 1 до 5");
        }
        if (!hasBought(user.getId(), id)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Оставить отзыв можно только на купленный товар");
        }
        if (reviewRepository.existsByProductIdAndUserId(id, user.getId())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Вы уже оставляли отзыв на этот товар");
        }

        Review review = new Review();
        review.setProductId(id);
        review.setUserId(user.getId());
        review.setRating(req.getRating());
        review.setText(req.getText());
        reviewRepository.save(review);
        updateRating(id);
        return review;
    }

    @PatchMapping("/reviews/{id}")
    public Review edit(@AuthenticationPrincipal User user, @PathVariable Long id, @RequestBody ReviewRequest req) {
        Review review = reviewRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Отзыв не найден"));
        if (!review.getUserId().equals(user.getId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Можно менять только свои отзывы");
        }
        if (req.getRating() != null) {
            if (req.getRating() < 1 || req.getRating() > 5) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Оценка должна быть от 1 до 5");
            }
            review.setRating(req.getRating());
        }
        if (req.getText() != null) {
            review.setText(req.getText());
        }
        reviewRepository.save(review);
        updateRating(review.getProductId());
        return review;
    }

    @DeleteMapping("/reviews/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@AuthenticationPrincipal User user, @PathVariable Long id) {
        Review review = reviewRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Отзыв не найден"));

        boolean isAuthor = review.getUserId().equals(user.getId());
        boolean isStaff = user.getRole() == Role.manager || user.getRole() == Role.admin;
        if (!isAuthor && !isStaff) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Нельзя удалить чужой отзыв");
        }

        reviewRepository.delete(review);
        updateRating(review.getProductId());
    }
}
