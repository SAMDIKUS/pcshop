package com.shop.controller;

import com.shop.dto.OrderRequest;
import com.shop.dto.StatusRequest;
import com.shop.entity.*;
import com.shop.repository.OrderRepository;
import com.shop.repository.OrderStatusHistoryRepository;
import com.shop.service.OrderService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

    private final OrderRepository orderRepository;
    private final OrderStatusHistoryRepository historyRepository;
    private final OrderService orderService;

    public OrderController(OrderRepository orderRepository, OrderStatusHistoryRepository historyRepository,
                           OrderService orderService) {
        this.orderRepository = orderRepository;
        this.historyRepository = historyRepository;
        this.orderService = orderService;
    }

    private ShopOrder findOrder(Long id, User user) {
        ShopOrder order = orderRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Заказ не найден"));
        if (user.getRole() == Role.customer && !order.getUserId().equals(user.getId())) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Заказ не найден");
        }
        return order;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ShopOrder create(@AuthenticationPrincipal User user, @RequestBody OrderRequest req) {
        return orderService.createOrder(user, req);
    }

    @GetMapping
    public List<ShopOrder> list(@AuthenticationPrincipal User user,
                                @RequestParam(name = "status", required = false) String status,
                                @RequestParam(name = "date_from", required = false)
                                @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFrom,
                                @RequestParam(name = "date_to", required = false)
                                @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateTo) {
        List<ShopOrder> all;
        if (user.getRole() == Role.manager) {
            all = orderRepository.findAll();
        } else {
            all = orderRepository.findByUserId(user.getId());
        }

        OrderStatus wanted = null;
        if (status != null && !status.isBlank()) {
            try {
                wanted = OrderStatus.parse(status);
            } catch (IllegalArgumentException e) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Неизвестный статус: " + status);
            }
        }

        List<ShopOrder> result = new ArrayList<>();
        for (ShopOrder o : all) {
            if (wanted != null && o.getStatus() != wanted) {
                continue;
            }
            LocalDate d = o.getCreatedAt().toLocalDate();
            if (dateFrom != null && d.isBefore(dateFrom)) {
                continue;
            }
            if (dateTo != null && d.isAfter(dateTo)) {
                continue;
            }
            result.add(o);
        }
        result.sort(Comparator.comparing(ShopOrder::getCreatedAt).reversed());
        return result;
    }

    @GetMapping("/{id}")
    public ShopOrder getOne(@AuthenticationPrincipal User user, @PathVariable Long id) {
        return findOrder(id, user);
    }

    @GetMapping("/{id}/status-history")
    public List<OrderStatusHistory> history(@AuthenticationPrincipal User user, @PathVariable Long id) {
        findOrder(id, user);
        return historyRepository.findByOrderIdOrderByChangedAtAsc(id);
    }

    @PostMapping("/{id}/cancel")
    public ShopOrder cancel(@AuthenticationPrincipal User user, @PathVariable Long id) {
        ShopOrder order = findOrder(id, user);
        return orderService.cancel(order);
    }

    @PatchMapping("/{id}/status")
    public ShopOrder setStatus(@PathVariable Long id, @RequestBody StatusRequest req) {
        ShopOrder order = orderRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Заказ не найден"));
        return orderService.changeStatus(order, req.getStatus());
    }
}
