package com.shop.controller;

import com.shop.dto.ReturnCreateRequest;
import com.shop.dto.ReturnDecisionRequest;
import com.shop.entity.*;
import com.shop.repository.OrderItemRepository;
import com.shop.repository.ReturnRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/returns")
public class ReturnController {

    private final ReturnRepository returnRepository;
    private final OrderItemRepository orderItemRepository;

    public ReturnController(ReturnRepository returnRepository, OrderItemRepository orderItemRepository) {
        this.returnRepository = returnRepository;
        this.orderItemRepository = orderItemRepository;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ReturnRequest create(@AuthenticationPrincipal User user, @RequestBody ReturnCreateRequest req) {
        if (req.getOrderItemId() == null || req.getType() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Укажите товар заказа и тип заявки");
        }
        if (req.getReason() == null || req.getReason().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Укажите причину");
        }

        OrderItem item = orderItemRepository.findById(req.getOrderItemId()).orElse(null);
        if (item == null || !item.getOrder().getUserId().equals(user.getId())) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Позиция заказа не найдена");
        }
        if (item.getOrder().getStatus() != OrderStatus.delivered) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Вернуть можно только доставленный заказ");
        }
        if (returnRepository.existsByOrderItemId(item.getId())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Заявка по этой позиции уже есть");
        }

        ReturnRequest r = new ReturnRequest();
        r.setOrderId(item.getOrder().getId());
        r.setOrderItemId(item.getId());
        r.setUserId(user.getId());
        r.setType(req.getType());
        r.setReason(req.getReason());
        return returnRepository.save(r);
    }

    @GetMapping
    public List<ReturnRequest> list(@AuthenticationPrincipal User user) {
        if (user.getRole() == Role.manager) {
            return returnRepository.findAll();
        }
        return returnRepository.findByUserId(user.getId());
    }

    @GetMapping("/{id}")
    public ReturnRequest getOne(@AuthenticationPrincipal User user, @PathVariable Long id) {
        ReturnRequest r = returnRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Заявка не найдена"));
        if (user.getRole() == Role.customer && !r.getUserId().equals(user.getId())) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Заявка не найдена");
        }
        return r;
    }

    @PatchMapping("/{id}")
    public ReturnRequest decide(@PathVariable Long id, @RequestBody ReturnDecisionRequest req) {
        ReturnRequest r = returnRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Заявка не найдена"));
        ReturnStatus now = r.getStatus();
        ReturnStatus next = req.getStatus();

        if (next == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Не указан статус");
        }
        if (now == ReturnStatus.new_request && (next == ReturnStatus.approved || next == ReturnStatus.rejected)) {
            r.setStatus(next);
        } else if (now == ReturnStatus.approved && next == ReturnStatus.completed) {
            r.setStatus(next);
        } else {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Такой переход статуса невозможен");
        }
        return returnRepository.save(r);
    }
}
