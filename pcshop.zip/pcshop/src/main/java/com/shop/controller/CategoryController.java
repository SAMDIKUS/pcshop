package com.shop.controller;

import com.shop.dto.CategoryNode;
import com.shop.entity.Brand;
import com.shop.entity.Category;
import com.shop.entity.Product;
import com.shop.repository.BrandRepository;
import com.shop.repository.CategoryRepository;
import com.shop.repository.ProductRepository;
import com.shop.service.ProductService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.*;

@RestController
@RequestMapping("/categories")
public class CategoryController {

    private final CategoryRepository categoryRepository;
    private final ProductRepository productRepository;
    private final BrandRepository brandRepository;
    private final ProductService productService;

    public CategoryController(CategoryRepository categoryRepository, ProductRepository productRepository,
                              BrandRepository brandRepository, ProductService productService) {
        this.categoryRepository = categoryRepository;
        this.productRepository = productRepository;
        this.brandRepository = brandRepository;
        this.productService = productService;
    }

    @GetMapping
    public List<CategoryNode> tree() {
        List<Category> all = categoryRepository.findAll();
        Map<Long, CategoryNode> nodes = new LinkedHashMap<>();

        for (Category c : all) {
            CategoryNode n = new CategoryNode();
            n.setId(c.getId());
            n.setName(c.getName());
            n.setParentId(c.getParentId());
            nodes.put(c.getId(), n);
        }

        List<CategoryNode> roots = new ArrayList<>();
        for (CategoryNode n : nodes.values()) {
            if (n.getParentId() == null || !nodes.containsKey(n.getParentId())) {
                roots.add(n);
            } else {
                nodes.get(n.getParentId()).getChildren().add(n);
            }
        }
        return roots;
    }

    @GetMapping("/{id}/filters")
    public Map<String, Object> filters(@PathVariable Long id) {
        if (!categoryRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Категория не найдена");
        }

        List<Product> products = new ArrayList<>();
        for (Long cid : productService.categoryWithChildren(id)) {
            products.addAll(productRepository.findByCategoryIdAndActiveTrue(cid));
        }

        Set<Long> brandIds = new HashSet<>();
        BigDecimal min = null;
        BigDecimal max = null;
        Map<String, Set<String>> specs = new TreeMap<>();

        for (Product p : products) {
            brandIds.add(p.getBrandId());
            if (min == null || p.getPrice().compareTo(min) < 0) {
                min = p.getPrice();
            }
            if (max == null || p.getPrice().compareTo(max) > 0) {
                max = p.getPrice();
            }
            for (Map.Entry<String, String> e : p.getSpecs().entrySet()) {
                if (!specs.containsKey(e.getKey())) {
                    specs.put(e.getKey(), new TreeSet<>());
                }
                specs.get(e.getKey()).add(e.getValue());
            }
        }

        List<Brand> brands = new ArrayList<>();
        for (Long bid : brandIds) {
            brandRepository.findById(bid).ifPresent(brands::add);
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("category_id", id);
        result.put("brands", brands);
        result.put("price_min", min);
        result.put("price_max", max);
        result.put("specs", specs);
        return result;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Category create(@RequestBody Category body) {
        checkCategory(body, null);
        body.setId(null);
        return categoryRepository.save(body);
    }

    @PutMapping("/{id}")
    public Category replace(@PathVariable Long id, @RequestBody Category body) {
        Category c = categoryRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Категория не найдена"));
        checkCategory(body, id);
        c.setName(body.getName());
        c.setParentId(body.getParentId());
        return categoryRepository.save(c);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        if (!categoryRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Категория не найдена");
        }
        if (!categoryRepository.findByParentId(id).isEmpty()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "У категории есть подкатегории");
        }
        if (productRepository.existsByCategoryId(id)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "В категории есть товары");
        }
        categoryRepository.deleteById(id);
    }

    private void checkCategory(Category body, Long selfId) {
        if (body.getName() == null || body.getName().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Не указано название");
        }
        if (body.getParentId() != null) {
            if (body.getParentId().equals(selfId)) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Категория не может быть родителем самой себе");
            }
            if (!categoryRepository.existsById(body.getParentId())) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Родительская категория не найдена");
            }
        }
    }
}
