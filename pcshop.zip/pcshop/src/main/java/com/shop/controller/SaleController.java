package com.shop.controller;

import com.shop.entity.Sale;
import com.shop.repository.SaleRepository;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/sale")
public class SaleController {

    private final SaleRepository saleRepository;

    public SaleController(SaleRepository saleRepository) {
        this.saleRepository = saleRepository;
    }

    @GetMapping
    public List<Sale> list() {
        return saleRepository.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Sale create(@RequestBody Sale body) {
        check(body);
        if (saleRepository.findByCodeAndActiveTrue(body.getCode()).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Такой промокод уже есть");
        }
        body.setId(null);
        return saleRepository.save(body);
    }

    @PutMapping("/{id}")
    public Sale replace(@PathVariable Long id, @RequestBody Sale body) {
        Sale s = saleRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Правило не найдено"));
        check(body);
        s.setName(body.getName());
        s.setCode(body.getCode());
        s.setPercent(body.getPercent());
        s.setActive(body.isActive());
        return saleRepository.save(s);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        if (!saleRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Правило не найдено");
        }
        saleRepository.deleteById(id);
    }

    private void check(Sale body) {
        if (body.getCode() == null || body.getCode().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Не указан промокод");
        }
        if (body.getPercent() < 1 || body.getPercent() > 100) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Скидка должна быть от 1 до 100 процентов");
        }
    }
}
