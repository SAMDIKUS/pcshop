package com.shop.controller;

import com.shop.entity.Brand;
import com.shop.repository.BrandRepository;
import com.shop.repository.ProductRepository;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/brands")
public class BrandController {

    private final BrandRepository brandRepository;
    private final ProductRepository productRepository;

    public BrandController(BrandRepository brandRepository, ProductRepository productRepository) {
        this.brandRepository = brandRepository;
        this.productRepository = productRepository;
    }

    @GetMapping
    public List<Brand> list() {
        return brandRepository.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Brand create(@RequestBody Brand body) {
        if (body.getName() == null || body.getName().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Не указано название");
        }
        body.setId(null);
        return brandRepository.save(body);
    }

    @PutMapping("/{id}")
    public Brand replace(@PathVariable Long id, @RequestBody Brand body) {
        Brand brand = brandRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Бренд не найден"));
        if (body.getName() == null || body.getName().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Не указано название");
        }
        brand.setName(body.getName());
        return brandRepository.save(brand);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        if (!brandRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Бренд не найден");
        }
        if (productRepository.existsByBrandId(id)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "У бренда есть товары");
        }
        brandRepository.deleteById(id);
    }
}
