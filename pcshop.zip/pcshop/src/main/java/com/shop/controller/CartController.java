package com.shop.controller;

import com.shop.dto.CartRequest;
import com.shop.entity.CartItem;
import com.shop.entity.Sale;
import com.shop.entity.User;
import com.shop.repository.SaleRepository;
import com.shop.service.CartService;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/cart")
public class CartController {

    private final CartService cartService;
    private final SaleRepository saleRepository;

    public CartController(CartService cartService, SaleRepository saleRepository) {
        this.cartService = cartService;
        this.saleRepository = saleRepository;
    }

    @GetMapping("/promo")
    public Map<String, Object> checkPromo(@RequestParam String code) {
        Sale sale = saleRepository.findByCodeAndActiveTrue(code.trim())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Промокод не найден"));
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("code", sale.getCode());
        result.put("percent", sale.getPercent());
        return result;
    }

    @GetMapping
    public Map<String, Object> get(@AuthenticationPrincipal User user) {
        return cartService.view(user.getId());
    }

    @PostMapping("/items")
    @ResponseStatus(HttpStatus.CREATED)
    public CartItem add(@AuthenticationPrincipal User user, @RequestBody CartRequest req) {
        return cartService.add(user.getId(), req.getProductId(), req.getQuantity());
    }

    @PatchMapping("/items/{id}")
    public CartItem change(@AuthenticationPrincipal User user, @PathVariable Long id, @RequestBody CartRequest req) {
        return cartService.changeQuantity(user.getId(), id, req.getQuantity());
    }

    @DeleteMapping("/items/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void remove(@AuthenticationPrincipal User user, @PathVariable Long id) {
        cartService.removeItem(user.getId(), id);
    }

    @DeleteMapping
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void clear(@AuthenticationPrincipal User user) {
        cartService.clear(user.getId());
    }
}
