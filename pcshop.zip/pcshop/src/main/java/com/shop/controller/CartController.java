package com.shop.controller;

import com.shop.dto.CartRequest;
import com.shop.entity.CartItem;
import com.shop.entity.User;
import com.shop.service.CartService;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/cart")
public class CartController {

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @GetMapping
    public Map<String, Object> get(@AuthenticationPrincipal User user) {
        return cartService.view(user.getId());
    }

    @PostMapping("/items")
    @ResponseStatus(HttpStatus.CREATED)
    public CartItem add(@AuthenticationPrincipal User user, @RequestBody CartRequest req) {
        return cartService.add(user.getId(), req.getProductId(), req.getQuantity());
    }

    @PatchMapping("/items/{id}")
    public CartItem change(@AuthenticationPrincipal User user, @PathVariable Long id, @RequestBody CartRequest req) {
        return cartService.changeQuantity(user.getId(), id, req.getQuantity());
    }

    @DeleteMapping("/items/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void remove(@AuthenticationPrincipal User user, @PathVariable Long id) {
        cartService.removeItem(user.getId(), id);
    }

    @DeleteMapping
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void clear(@AuthenticationPrincipal User user) {
        cartService.clear(user.getId());
    }
}
