package com.shop.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum ReturnStatus {
    @JsonProperty("new")
    new_request,
    approved,
    rejected,
    completed
}
