package com.shop.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
public class Supply {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long supplierId;
    @Column(name = "supply_date")
    private LocalDateTime date = LocalDateTime.now();

    @OneToMany(mappedBy = "supply", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<SupplyItem> items = new ArrayList<>();
}
