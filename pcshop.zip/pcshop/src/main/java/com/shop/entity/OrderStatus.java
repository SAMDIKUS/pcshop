package com.shop.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum OrderStatus {
    @JsonProperty("new")
    new_order,
    processing,
    assembled,
    shipped,
    delivered,
    cancelled;

    public static OrderStatus parse(String text) {
        if (text.equals("new")) {
            return new_order;
        }
        return valueOf(text);
    }
}
