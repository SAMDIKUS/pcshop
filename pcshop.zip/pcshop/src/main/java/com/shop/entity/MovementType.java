package com.shop.entity;

public enum MovementType {
    supply, sale, write_off
}
