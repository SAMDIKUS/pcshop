package com.shop.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "configurations")
@Getter
@Setter
public class Configuration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private String name;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "configuration_products", joinColumns = @JoinColumn(name = "configuration_id"))
    @Column(name = "product_id")
    private List<Long> productIds = new ArrayList<>();

    private LocalDateTime createdAt = LocalDateTime.now();
}
