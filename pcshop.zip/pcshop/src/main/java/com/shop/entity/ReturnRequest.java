package com.shop.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
public class ReturnRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long orderId;
    private Long orderItemId;
    private Long userId;

    @Enumerated(EnumType.STRING)
    private ReturnType type;

    private String reason;

    @Enumerated(EnumType.STRING)
    private ReturnStatus status = ReturnStatus.new_request;

    private LocalDateTime createdAt = LocalDateTime.now();
}
