package com.shop.entity;

public enum Role {
    customer, manager, admin, storekeeper
}
