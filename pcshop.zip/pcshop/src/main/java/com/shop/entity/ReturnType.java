package com.shop.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum ReturnType {
    @JsonProperty("return")
    return_item,
    exchange
}
