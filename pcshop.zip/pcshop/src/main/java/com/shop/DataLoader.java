package com.shop;

import com.shop.entity.*;
import com.shop.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class DataLoader implements CommandLineRunner {

    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final BrandRepository brandRepository;
    private final ProductRepository productRepository;
    private final PaymentMethodRepository paymentRepository;
    private final DeliveryMethodRepository deliveryRepository;
    private final SaleRepository saleRepository;
    private final SupplierRepository supplierRepository;
    private final PasswordEncoder passwordEncoder;

    public DataLoader(UserRepository userRepository, CategoryRepository categoryRepository,
                      BrandRepository brandRepository, ProductRepository productRepository,
                      PaymentMethodRepository paymentRepository, DeliveryMethodRepository deliveryRepository,
                      SaleRepository saleRepository, SupplierRepository supplierRepository,
                      PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.categoryRepository = categoryRepository;
        this.brandRepository = brandRepository;
        this.productRepository = productRepository;
        this.paymentRepository = paymentRepository;
        this.deliveryRepository = deliveryRepository;
        this.saleRepository = saleRepository;
        this.supplierRepository = supplierRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (userRepository.count() == 0) {
            addBase();
        }
        addProducts();
    }

    private void addBase() {
        addUser("admin@shop.ru", "admin123", "Администратор", Role.admin);
        addUser("manager@shop.ru", "manager123", "Менеджер Иван", Role.manager);
        addUser("store@shop.ru", "store123", "Кладовщик Пётр", Role.storekeeper);
        addUser("user@shop.ru", "user123", "Покупатель Антон", Role.customer);

        PaymentMethod card = new PaymentMethod();
        card.setName("Картой онлайн");
        paymentRepository.save(card);

        PaymentMethod cash = new PaymentMethod();
        cash.setName("Наличными при получении");
        paymentRepository.save(cash);

        addDelivery("Самовывоз", 0);
        addDelivery("Курьер", 500);
        addDelivery("Транспортная компания", 900);

        Sale sale = new Sale();
        sale.setName("Скидка новым покупателям");
        sale.setCode("WELCOME10");
        sale.setPercent(10);
        saleRepository.save(sale);

        Supplier supplier = new Supplier();
        supplier.setName("ООО ТехСнаб");
        supplier.setContacts("+7 900 000-00-00, sales@techsnab.ru");
        supplierRepository.save(supplier);
    }

    private void addProducts() {
        addProduct("CPU-001", "Intel Core i5-13400F", 18990, "Процессоры", "Intel", 15,
                "component", "cpu", "socket", "LGA1700", "tdp_w", "65");
        addProduct("CPU-002", "Intel Core i7-13700K", 41990, "Процессоры", "Intel", 8,
                "component", "cpu", "socket", "LGA1700", "tdp_w", "125");
        addProduct("CPU-003", "AMD Ryzen 5 7600", 21990, "Процессоры", "AMD", 10,
                "component", "cpu", "socket", "AM5", "tdp_w", "65");

        addProduct("COOL-001", "DeepCool AK400", 2990, "Охлаждение процессора", "DeepCool", 18,
                "component", "cooler", "sockets", "LGA1700,AM5", "cooler_tdp_w", "220", "cooler_height_mm", "155");
        addProduct("COOL-002", "Noctua NH-U12S", 7490, "Охлаждение процессора", "Noctua", 7,
                "component", "cooler", "sockets", "LGA1700,AM5", "cooler_tdp_w", "180", "cooler_height_mm", "158");
        addProduct("COOL-003", "Arctic Freezer 36", 3490, "Охлаждение процессора", "Arctic", 11,
                "component", "cooler", "sockets", "LGA1700,AM5", "cooler_tdp_w", "210", "cooler_height_mm", "159");

        addProduct("MB-001", "ASUS PRIME B760M-A D4", 11990, "Материнские платы", "ASUS", 12,
                "component", "motherboard", "socket", "LGA1700", "ram_type", "DDR4",
                "form_factor", "mATX", "ram_slots", "4", "m2_slots", "2", "sata_ports", "4");
        addProduct("MB-002", "MSI MAG B650 TOMAHAWK", 22990, "Материнские платы", "MSI", 6,
                "component", "motherboard", "socket", "AM5", "ram_type", "DDR5",
                "form_factor", "ATX", "ram_slots", "4", "m2_slots", "2", "sata_ports", "6");
        addProduct("MB-003", "Gigabyte Z790 AORUS ELITE", 24990, "Материнские платы", "Gigabyte", 5,
                "component", "motherboard", "socket", "LGA1700", "ram_type", "DDR5",
                "form_factor", "ATX", "ram_slots", "4", "m2_slots", "3", "sata_ports", "6");

        addProduct("RAM-001", "Kingston FURY Beast 16GB DDR4", 3990, "Оперативная память", "Kingston", 30,
                "component", "ram", "ram_type", "DDR4", "ram_capacity_gb", "16");
        addProduct("RAM-002", "Corsair Vengeance 32GB DDR5", 9990, "Оперативная память", "Corsair", 20,
                "component", "ram", "ram_type", "DDR5", "ram_capacity_gb", "32");

        addProduct("SSD-001", "Samsung 980 PRO 1TB", 9990, "Накопители", "Samsung", 12,
                "component", "storage", "storage_type", "NVMe", "storage_capacity_gb", "1000");
        addProduct("SSD-002", "Kingston NV2 500GB", 3490, "Накопители", "Kingston", 20,
                "component", "storage", "storage_type", "NVMe", "storage_capacity_gb", "500");
        addProduct("SSD-003", "WD Blue SN580 1TB", 6490, "Накопители", "Western Digital", 14,
                "component", "storage", "storage_type", "NVMe", "storage_capacity_gb", "1000");
        addProduct("SSD-004", "Crucial MX500 1TB", 6990, "Накопители", "Crucial", 9,
                "component", "storage", "storage_type", "SATA", "storage_capacity_gb", "1000");
        addProduct("HDD-001", "Seagate Barracuda 2TB", 4990, "Накопители", "Seagate", 8,
                "component", "storage", "storage_type", "HDD", "storage_capacity_gb", "2000");

        addProduct("GPU-001", "MSI GeForce RTX 4060 Ventus", 32990, "Видеокарты", "MSI", 7,
                "component", "gpu", "tdp_w", "115");
        addProduct("GPU-002", "ASUS GeForce RTX 4070 Super", 64990, "Видеокарты", "ASUS", 4,
                "component", "gpu", "tdp_w", "220");

        addProduct("PSU-001", "Corsair CV550 550W", 4990, "Блоки питания", "Corsair", 14,
                "component", "psu", "psu_power_w", "550");
        addProduct("PSU-002", "Corsair RM750e 750W", 11990, "Блоки питания", "Corsair", 9,
                "component", "psu", "psu_power_w", "750");

        addProduct("CASE-001", "Corsair 4000D Airflow", 8990, "Корпуса", "Corsair", 10,
                "component", "case", "form_factor", "ATX", "max_cooler_height_mm", "170");
        addProduct("CASE-002", "Deepcool MACUBE 110", 5490, "Корпуса", "DeepCool", 6,
                "component", "case", "form_factor", "mATX", "max_cooler_height_mm", "165");
    }

    private void addUser(String email, String password, String name, Role role) {
        User u = new User();
        u.setEmail(email);
        u.setPassword(passwordEncoder.encode(password));
        u.setFullName(name);
        u.setRole(role);
        userRepository.save(u);
    }

    private Long getCategoryId(String name) {
        Category c = categoryRepository.findFirstByName(name).orElse(null);
        if (c == null) {
            c = new Category();
            c.setName(name);
            c = categoryRepository.save(c);
        }
        return c.getId();
    }

    private Long getBrandId(String name) {
        Brand b = brandRepository.findFirstByName(name).orElse(null);
        if (b == null) {
            b = new Brand();
            b.setName(name);
            b = brandRepository.save(b);
        }
        return b.getId();
    }

    private void addDelivery(String name, int price) {
        DeliveryMethod d = new DeliveryMethod();
        d.setName(name);
        d.setPrice(BigDecimal.valueOf(price));
        deliveryRepository.save(d);
    }

    private void addProduct(String sku, String name, int price, String categoryName, String brandName, int stock,
                            String... specs) {
        Product p = productRepository.findBySku(sku).orElse(null);
        if (p == null) {
            p = new Product();
            p.setSku(sku);
            p.setName(name);
            p.setDescription(name);
            p.setPrice(BigDecimal.valueOf(price));
            p.setCategoryId(getCategoryId(categoryName));
            p.setBrandId(getBrandId(brandName));
            p.setStockQuantity(stock);
        }
        for (int i = 0; i < specs.length; i = i + 2) {
            if (!p.getSpecs().containsKey(specs[i])) {
                p.getSpecs().put(specs[i], specs[i + 1]);
            }
        }
        productRepository.save(p);
    }
}
