package com.shop;

import com.shop.entity.*;
import com.shop.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class DataLoader implements CommandLineRunner {

    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final BrandRepository brandRepository;
    private final ProductRepository productRepository;
    private final PaymentMethodRepository paymentRepository;
    private final DeliveryMethodRepository deliveryRepository;
    private final SaleRepository saleRepository;
    private final SupplierRepository supplierRepository;
    private final PasswordEncoder passwordEncoder;

    public DataLoader(UserRepository userRepository, CategoryRepository categoryRepository,
                      BrandRepository brandRepository, ProductRepository productRepository,
                      PaymentMethodRepository paymentRepository, DeliveryMethodRepository deliveryRepository,
                      SaleRepository saleRepository, SupplierRepository supplierRepository,
                      PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.categoryRepository = categoryRepository;
        this.brandRepository = brandRepository;
        this.productRepository = productRepository;
        this.paymentRepository = paymentRepository;
        this.deliveryRepository = deliveryRepository;
        this.saleRepository = saleRepository;
        this.supplierRepository = supplierRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (userRepository.count() > 0) {
            return;
        }

        addUser("admin@shop.ru", "admin123", "Администратор", Role.admin);
        addUser("manager@shop.ru", "manager123", "Менеджер Иван", Role.manager);
        addUser("store@shop.ru", "store123", "Кладовщик Пётр", Role.storekeeper);
        addUser("user@shop.ru", "user123", "Покупатель Антон", Role.customer);

        Long cpu = addCategory("Процессоры");
        Long board = addCategory("Материнские платы");
        Long ram = addCategory("Оперативная память");
        Long gpu = addCategory("Видеокарты");
        Long psu = addCategory("Блоки питания");
        Long pcCase = addCategory("Корпуса");

        Long intel = addBrand("Intel");
        Long amd = addBrand("AMD");
        Long asus = addBrand("ASUS");
        Long msi = addBrand("MSI");
        Long gigabyte = addBrand("Gigabyte");
        Long kingston = addBrand("Kingston");
        Long corsair = addBrand("Corsair");
        Long deepcool = addBrand("Deepcool");

        addProduct("CPU-001", "Intel Core i5-13400F", 18990, cpu, intel, 15,
                "component", "cpu", "socket", "LGA1700", "tdp_w", "65");
        addProduct("CPU-002", "Intel Core i7-13700K", 41990, cpu, intel, 8,
                "component", "cpu", "socket", "LGA1700", "tdp_w", "125");
        addProduct("CPU-003", "AMD Ryzen 5 7600", 21990, cpu, amd, 10,
                "component", "cpu", "socket", "AM5", "tdp_w", "65");

        addProduct("MB-001", "ASUS PRIME B760M-A D4", 11990, board, asus, 12,
                "component", "motherboard", "socket", "LGA1700", "ram_type", "DDR4",
                "form_factor", "mATX", "ram_slots", "4");
        addProduct("MB-002", "MSI MAG B650 TOMAHAWK", 22990, board, msi, 6,
                "component", "motherboard", "socket", "AM5", "ram_type", "DDR5",
                "form_factor", "ATX", "ram_slots", "4");
        addProduct("MB-003", "Gigabyte Z790 AORUS ELITE", 24990, board, gigabyte, 5,
                "component", "motherboard", "socket", "LGA1700", "ram_type", "DDR5",
                "form_factor", "ATX", "ram_slots", "4");

        addProduct("RAM-001", "Kingston FURY Beast 16GB DDR4", 3990, ram, kingston, 30,
                "component", "ram", "ram_type", "DDR4", "ram_capacity_gb", "16");
        addProduct("RAM-002", "Corsair Vengeance 32GB DDR5", 9990, ram, corsair, 20,
                "component", "ram", "ram_type", "DDR5", "ram_capacity_gb", "32");

        addProduct("GPU-001", "MSI GeForce RTX 4060 Ventus", 32990, gpu, msi, 7,
                "component", "gpu", "tdp_w", "115");
        addProduct("GPU-002", "ASUS GeForce RTX 4070 Super", 64990, gpu, asus, 4,
                "component", "gpu", "tdp_w", "220");

        addProduct("PSU-001", "Corsair CV550 550W", 4990, psu, corsair, 14,
                "component", "psu", "psu_power_w", "550");
        addProduct("PSU-002", "Corsair RM750e 750W", 11990, psu, corsair, 9,
                "component", "psu", "psu_power_w", "750");

        addProduct("CASE-001", "Corsair 4000D Airflow", 8990, pcCase, corsair, 10,
                "component", "case", "form_factor", "ATX");
        addProduct("CASE-002", "Deepcool MACUBE 110", 5490, pcCase, deepcool, 6,
                "component", "case", "form_factor", "mATX");

        PaymentMethod card = new PaymentMethod();
        card.setName("Картой онлайн");
        paymentRepository.save(card);

        PaymentMethod cash = new PaymentMethod();
        cash.setName("Наличными при получении");
        paymentRepository.save(cash);

        addDelivery("Самовывоз", 0);
        addDelivery("Курьер", 500);
        addDelivery("Транспортная компания", 900);

        Sale sale = new Sale();
        sale.setName("Скидка новым покупателям");
        sale.setCode("WELCOME10");
        sale.setPercent(10);
        saleRepository.save(sale);

        Supplier supplier = new Supplier();
        supplier.setName("ООО ТехСнаб");
        supplier.setContacts("+7 900 000-00-00, sales@techsnab.ru");
        supplierRepository.save(supplier);
    }

    private void addUser(String email, String password, String name, Role role) {
        User u = new User();
        u.setEmail(email);
        u.setPassword(passwordEncoder.encode(password));
        u.setFullName(name);
        u.setRole(role);
        userRepository.save(u);
    }

    private Long addCategory(String name) {
        Category c = new Category();
        c.setName(name);
        return categoryRepository.save(c).getId();
    }

    private Long addBrand(String name) {
        Brand b = new Brand();
        b.setName(name);
        return brandRepository.save(b).getId();
    }

    private void addDelivery(String name, int price) {
        DeliveryMethod d = new DeliveryMethod();
        d.setName(name);
        d.setPrice(BigDecimal.valueOf(price));
        deliveryRepository.save(d);
    }

    private void addProduct(String sku, String name, int price, Long categoryId, Long brandId, int stock,
                            String... specs) {
        Product p = new Product();
        p.setSku(sku);
        p.setName(name);
        p.setDescription(name);
        p.setPrice(BigDecimal.valueOf(price));
        p.setCategoryId(categoryId);
        p.setBrandId(brandId);
        p.setStockQuantity(stock);
        for (int i = 0; i < specs.length; i = i + 2) {
            p.getSpecs().put(specs[i], specs[i + 1]);
        }
        productRepository.save(p);
    }
}
