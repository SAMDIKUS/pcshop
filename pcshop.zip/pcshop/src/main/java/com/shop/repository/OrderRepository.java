package com.shop.repository;

import com.shop.entity.ShopOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.time.LocalDateTime;
import java.util.List;

public interface OrderRepository extends JpaRepository<ShopOrder, Long>, JpaSpecificationExecutor<ShopOrder> {

    List<ShopOrder> findByCreatedAtBetween(LocalDateTime from, LocalDateTime to);

    List<ShopOrder> findByUserId(Long userId);
}
