package com.shop.repository;

import com.shop.entity.DeliveryMethod;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DeliveryMethodRepository extends JpaRepository<DeliveryMethod, Long> {

    List<DeliveryMethod> findByActiveTrue();
}
