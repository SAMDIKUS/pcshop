package com.shop.repository;

import com.shop.entity.Configuration;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ConfigurationRepository extends JpaRepository<Configuration, Long> {

    List<Configuration> findByUserId(Long userId);
}
