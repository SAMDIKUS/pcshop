package com.shop.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
public class SecurityConfig {

    private final JwtFilter jwtFilter;

    public SecurityConfig(JwtFilter jwtFilter) {
        this.jwtFilter = jwtFilter;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOriginPatterns(List.of("*"));
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf(AbstractHttpConfigurer::disable);
        http.cors(Customizer.withDefaults());
        http.sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
        http.exceptionHandling(e -> e.authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)));

        http.authorizeHttpRequests(auth -> auth
                .requestMatchers("/error").permitAll()
                .requestMatchers(HttpMethod.GET, "/", "/index.html", "/css/**", "/js/**", "/favicon.ico").permitAll()

                .requestMatchers(HttpMethod.POST, "/auth/register", "/auth/login", "/auth/refresh").permitAll()

                .requestMatchers(HttpMethod.POST, "/products/*/reviews").hasRole("CUSTOMER")
                .requestMatchers(HttpMethod.GET, "/products/**", "/categories/**", "/brands/**",
                        "/payment-methods", "/delivery-methods").permitAll()
                .requestMatchers(HttpMethod.GET, "/configurator/compatible-products").permitAll()
                .requestMatchers(HttpMethod.POST, "/configurator/check").permitAll()

                .requestMatchers("/products/**", "/categories/**", "/brands/**",
                        "/payment-methods/**", "/delivery-methods/**").hasRole("ADMIN")

                .requestMatchers("/users/me").authenticated()
                .requestMatchers("/users/**", "/users").hasRole("ADMIN")
                .requestMatchers("/sale/**", "/sale").hasRole("ADMIN")
                .requestMatchers("/analytics/**").hasRole("ADMIN")

                .requestMatchers("/stock/**", "/stock", "/supplies/**", "/supplies",
                        "/suppliers/**", "/suppliers").hasAnyRole("ADMIN", "STOREKEEPER")

                .requestMatchers("/cart/**", "/cart").hasRole("CUSTOMER")
                .requestMatchers("/configurations/**", "/configurations").hasRole("CUSTOMER")

                .requestMatchers(HttpMethod.POST, "/orders").hasRole("CUSTOMER")
                .requestMatchers(HttpMethod.PATCH, "/orders/*/status").hasRole("MANAGER")
                .requestMatchers(HttpMethod.POST, "/orders/*/promo").hasRole("MANAGER")
                .requestMatchers("/orders/**", "/orders").hasAnyRole("CUSTOMER", "MANAGER")

                .requestMatchers(HttpMethod.POST, "/returns").hasRole("CUSTOMER")
                .requestMatchers(HttpMethod.PATCH, "/returns/*").hasRole("MANAGER")
                .requestMatchers("/returns/**", "/returns").hasAnyRole("CUSTOMER", "MANAGER")

                .anyRequest().authenticated()
        );

        http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }
}
