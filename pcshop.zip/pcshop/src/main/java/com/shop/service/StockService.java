package com.shop.service;

import com.shop.dto.SupplyItemRequest;
import com.shop.dto.SupplyRequest;
import com.shop.dto.WriteOffRequest;
import com.shop.entity.*;
import com.shop.repository.ProductRepository;
import com.shop.repository.StockMovementRepository;
import com.shop.repository.SupplierRepository;
import com.shop.repository.SupplyRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
public class StockService {

    private final ProductRepository productRepository;
    private final StockMovementRepository movementRepository;
    private final SupplyRepository supplyRepository;
    private final SupplierRepository supplierRepository;

    public StockService(ProductRepository productRepository, StockMovementRepository movementRepository,
                        SupplyRepository supplyRepository, SupplierRepository supplierRepository) {
        this.productRepository = productRepository;
        this.movementRepository = movementRepository;
        this.supplyRepository = supplyRepository;
        this.supplierRepository = supplierRepository;
    }

    public void changeStock(Product product, MovementType type, int quantity, String reason) {
        if (type == MovementType.supply) {
            product.setStockQuantity(product.getStockQuantity() + quantity);
        } else {
            if (product.getStockQuantity() < quantity) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "Недостаточно товара на складе: " + product.getName());
            }
            product.setStockQuantity(product.getStockQuantity() - quantity);
        }
        productRepository.save(product);

        StockMovement m = new StockMovement();
        m.setProductId(product.getId());
        m.setType(type);
        m.setQuantity(quantity);
        m.setReason(reason);
        movementRepository.save(m);
    }

    @Transactional
    public Supply addSupply(SupplyRequest req) {
        if (req.getSupplierId() == null || !supplierRepository.existsById(req.getSupplierId())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Поставщик не найден");
        }
        if (req.getItems() == null || req.getItems().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Список товаров пуст");
        }

        Supply supply = new Supply();
        supply.setSupplierId(req.getSupplierId());

        for (SupplyItemRequest i : req.getItems()) {
            if (i.getQuantity() <= 0) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Количество должно быть больше нуля");
            }
            if (i.getPurchasePrice() == null) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Не указана закупочная цена");
            }
            Product product = productRepository.findById(i.getProductId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Товар не найден: " + i.getProductId()));

            SupplyItem item = new SupplyItem();
            item.setSupply(supply);
            item.setProductId(product.getId());
            item.setQuantity(i.getQuantity());
            item.setPurchasePrice(i.getPurchasePrice());
            supply.getItems().add(item);
        }

        supplyRepository.save(supply);

        for (SupplyItem item : supply.getItems()) {
            Product product = productRepository.findById(item.getProductId()).get();
            changeStock(product, MovementType.supply, item.getQuantity(), "поставка №" + supply.getId());
        }
        return supply;
    }

    @Transactional
    public StockMovement writeOff(WriteOffRequest req) {
        if (req.getQuantity() <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Количество должно быть больше нуля");
        }
        if (req.getReason() == null || req.getReason().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Укажите причину списания");
        }
        Product product = productRepository.findById(req.getProductId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Товар не найден"));

        changeStock(product, MovementType.write_off, req.getQuantity(), req.getReason());
        return movementRepository.findByProductIdOrderByCreatedAtDesc(product.getId()).get(0);
    }
}
