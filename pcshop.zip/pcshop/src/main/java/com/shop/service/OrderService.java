package com.shop.service;

import com.shop.dto.OrderRequest;
import com.shop.entity.*;
import com.shop.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final CartItemRepository cartRepository;
    private final ProductRepository productRepository;
    private final PaymentMethodRepository paymentRepository;
    private final DeliveryMethodRepository deliveryRepository;
    private final OrderStatusHistoryRepository historyRepository;
    private final SaleRepository saleRepository;
    private final StockService stockService;

    public OrderService(OrderRepository orderRepository, CartItemRepository cartRepository,
                        ProductRepository productRepository, PaymentMethodRepository paymentRepository,
                        DeliveryMethodRepository deliveryRepository, OrderStatusHistoryRepository historyRepository,
                        SaleRepository saleRepository, StockService stockService) {
        this.orderRepository = orderRepository;
        this.cartRepository = cartRepository;
        this.productRepository = productRepository;
        this.paymentRepository = paymentRepository;
        this.deliveryRepository = deliveryRepository;
        this.historyRepository = historyRepository;
        this.saleRepository = saleRepository;
        this.stockService = stockService;
    }

    @Transactional
    public ShopOrder createOrder(User user, OrderRequest req) {
        List<CartItem> cart = cartRepository.findByUserId(user.getId());
        if (cart.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Корзина пуста");
        }
        if (req.getAddress() == null || req.getAddress().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Укажите адрес");
        }

        PaymentMethod payment = null;
        if (req.getPaymentMethodId() != null) {
            payment = paymentRepository.findById(req.getPaymentMethodId()).orElse(null);
        }
        if (payment == null || !payment.isActive()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Неверный способ оплаты");
        }

        DeliveryMethod delivery = null;
        if (req.getDeliveryMethodId() != null) {
            delivery = deliveryRepository.findById(req.getDeliveryMethodId()).orElse(null);
        }
        if (delivery == null || !delivery.isActive()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Неверный способ доставки");
        }

        ShopOrder order = new ShopOrder();
        order.setUserId(user.getId());
        order.setAddress(req.getAddress());
        order.setPaymentMethodId(payment.getId());
        order.setDeliveryMethodId(delivery.getId());

        BigDecimal sum = BigDecimal.ZERO;
        for (CartItem c : cart) {
            Product product = productRepository.findById(c.getProductId()).orElse(null);
            if (product == null || !product.isActive()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Один из товаров больше недоступен");
            }
            if (product.getStockQuantity() < c.getQuantity()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "Недостаточно товара на складе: " + product.getName());
            }
            OrderItem item = new OrderItem();
            item.setOrder(order);
            item.setProductId(product.getId());
            item.setQuantity(c.getQuantity());
            item.setPrice(product.getPrice());
            order.getItems().add(item);
            sum = sum.add(product.getPrice().multiply(BigDecimal.valueOf(c.getQuantity())));
        }

        BigDecimal discount = BigDecimal.ZERO;
        if (req.getPromoCode() != null && !req.getPromoCode().isBlank()) {
            Sale sale = saleRepository.findByCodeAndActiveTrue(req.getPromoCode().trim())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Промокод не найден"));
            discount = sum.multiply(BigDecimal.valueOf(sale.getPercent()))
                    .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
            order.setPromoCode(sale.getCode());
            order.setDiscount(discount);
        }

        order.setTotal(sum.add(delivery.getPrice()).subtract(discount));
        orderRepository.save(order);

        for (OrderItem item : order.getItems()) {
            Product product = productRepository.findById(item.getProductId()).get();
            stockService.changeStock(product, MovementType.sale, item.getQuantity(), "заказ №" + order.getId());
        }

        addHistory(order.getId(), OrderStatus.new_order);
        cartRepository.deleteByUserId(user.getId());
        return order;
    }

    @Transactional
    public ShopOrder cancel(ShopOrder order) {
        OrderStatus s = order.getStatus();
        if (s == OrderStatus.shipped || s == OrderStatus.delivered || s == OrderStatus.cancelled) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Заказ уже нельзя отменить");
        }

        for (OrderItem item : order.getItems()) {
            Product product = productRepository.findById(item.getProductId()).orElse(null);
            if (product != null) {
                stockService.changeStock(product, MovementType.supply, item.getQuantity(),
                        "отмена заказа №" + order.getId());
            }
        }

        order.setStatus(OrderStatus.cancelled);
        orderRepository.save(order);
        addHistory(order.getId(), OrderStatus.cancelled);
        return order;
    }

    @Transactional
    public ShopOrder changeStatus(ShopOrder order, OrderStatus status) {
        if (status == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Не указан статус");
        }
        if (status == OrderStatus.cancelled) {
            return cancel(order);
        }
        OrderStatus current = order.getStatus();
        if (current == OrderStatus.delivered || current == OrderStatus.cancelled) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Статус этого заказа менять нельзя");
        }
        if (status.ordinal() <= current.ordinal()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Нельзя вернуть заказ на прошлый статус");
        }

        order.setStatus(status);
        orderRepository.save(order);
        addHistory(order.getId(), status);
        return order;
    }

    private void addHistory(Long orderId, OrderStatus status) {
        OrderStatusHistory h = new OrderStatusHistory();
        h.setOrderId(orderId);
        h.setStatus(status);
        historyRepository.save(h);
    }
}
