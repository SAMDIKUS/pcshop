package com.shop.service;

import com.shop.entity.CartItem;
import com.shop.entity.Product;
import com.shop.repository.CartItemRepository;
import com.shop.repository.ProductRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class CartService {

    private final CartItemRepository cartRepository;
    private final ProductRepository productRepository;

    public CartService(CartItemRepository cartRepository, ProductRepository productRepository) {
        this.cartRepository = cartRepository;
        this.productRepository = productRepository;
    }

    public CartItem add(Long userId, Long productId, int quantity) {
        if (quantity <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Количество должно быть больше нуля");
        }
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Товар не найден"));
        if (!product.isActive()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Товар снят с продажи");
        }

        CartItem item = cartRepository.findByUserIdAndProductId(userId, productId).orElse(null);
        int newQuantity = quantity;
        if (item != null) {
            newQuantity = item.getQuantity() + quantity;
        } else {
            item = new CartItem();
            item.setUserId(userId);
            item.setProductId(productId);
        }

        if (newQuantity > product.getStockQuantity()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "На складе только " + product.getStockQuantity() + " шт.");
        }
        item.setQuantity(newQuantity);
        return cartRepository.save(item);
    }

    public CartItem changeQuantity(Long userId, Long itemId, int quantity) {
        CartItem item = cartRepository.findById(itemId).orElse(null);
        if (item == null || !item.getUserId().equals(userId)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Позиция не найдена");
        }
        if (quantity <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Количество должно быть больше нуля");
        }
        Product product = productRepository.findById(item.getProductId()).get();
        if (quantity > product.getStockQuantity()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "На складе только " + product.getStockQuantity() + " шт.");
        }
        item.setQuantity(quantity);
        return cartRepository.save(item);
    }

    public void removeItem(Long userId, Long itemId) {
        CartItem item = cartRepository.findById(itemId).orElse(null);
        if (item == null || !item.getUserId().equals(userId)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Позиция не найдена");
        }
        cartRepository.delete(item);
    }

    @Transactional
    public void clear(Long userId) {
        cartRepository.deleteByUserId(userId);
    }

    public Map<String, Object> view(Long userId) {
        List<Map<String, Object>> lines = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;

        for (CartItem item : cartRepository.findByUserId(userId)) {
            Product product = productRepository.findById(item.getProductId()).orElse(null);
            if (product == null) {
                continue;
            }
            BigDecimal lineTotal = product.getPrice().multiply(BigDecimal.valueOf(item.getQuantity()));
            total = total.add(lineTotal);

            Map<String, Object> line = new LinkedHashMap<>();
            line.put("id", item.getId());
            line.put("product_id", product.getId());
            line.put("sku", product.getSku());
            line.put("image_url", product.getImageUrl());
            line.put("name", product.getName());
            line.put("price", product.getPrice());
            line.put("quantity", item.getQuantity());
            line.put("line_total", lineTotal);
            lines.add(line);
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("items", lines);
        result.put("total", total);
        return result;
    }
}
