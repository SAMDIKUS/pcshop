package com.shop.service;

import com.shop.entity.Product;
import com.shop.repository.ProductRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class ConfiguratorService {

    private final ProductRepository productRepository;

    private final String[] sizes = {"ITX", "mATX", "ATX", "E-ATX"};

    public ConfiguratorService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<Product> loadProducts(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Список товаров пуст");
        }
        List<Product> list = new ArrayList<>();
        for (Long id : ids) {
            Product p = productRepository.findById(id)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Товар не найден: " + id));
            list.add(p);
        }
        return list;
    }

    private int num(Product p, String key) {
        String v = p.getSpecs().get(key);
        if (v == null) {
            return 0;
        }
        try {
            return Integer.parseInt(v.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private boolean socketInList(String list, String socket) {
        for (String item : list.split(",")) {
            if (item.trim().equalsIgnoreCase(socket)) {
                return true;
            }
        }
        return false;
    }

    private int sizeIndex(String name) {
        if (name == null) {
            return -1;
        }
        for (int i = 0; i < sizes.length; i++) {
            if (sizes[i].equalsIgnoreCase(name.trim())) {
                return i;
            }
        }
        return -1;
    }

    private int powerNeeded(List<Product> products) {
        int sum = 100;
        for (Product p : products) {
            String type = p.getSpecs().get("component");
            if ("cpu".equals(type) || "gpu".equals(type)) {
                sum = sum + num(p, "tdp_w");
            }
        }
        return sum;
    }

    private void checkRules(List<Product> products, List<String> errors, List<String> warnings) {
        Product cpu = null;
        Product board = null;
        Product psu = null;
        Product pcCase = null;
        Product gpu = null;
        Product cooler = null;
        List<Product> storages = new ArrayList<>();
        List<Product> rams = new ArrayList<>();

        for (Product p : products) {
            String type = p.getSpecs().get("component");
            if (type == null) {
                warnings.add("У товара \"" + p.getName() + "\" не указан тип комплектующего, он не проверяется");
                continue;
            }
            switch (type) {
                case "cpu":
                    if (cpu != null) {
                        errors.add("В сборке может быть только один процессор");
                    } else {
                        cpu = p;
                    }
                    break;
                case "motherboard":
                    if (board != null) {
                        errors.add("В сборке может быть только одна материнская плата");
                    } else {
                        board = p;
                    }
                    break;
                case "psu":
                    if (psu != null) {
                        errors.add("В сборке может быть только один блок питания");
                    } else {
                        psu = p;
                    }
                    break;
                case "case":
                    if (pcCase != null) {
                        errors.add("В сборке может быть только один корпус");
                    } else {
                        pcCase = p;
                    }
                    break;
                case "gpu":
                    if (gpu != null) {
                        errors.add("В сборке может быть только одна видеокарта");
                    } else {
                        gpu = p;
                    }
                    break;
                case "cooler":
                    if (cooler != null) {
                        errors.add("В сборке может быть только один кулер процессора");
                    } else {
                        cooler = p;
                    }
                    break;
                case "storage":
                    storages.add(p);
                    break;
                case "ram":
                    rams.add(p);
                    break;
                default:
                    break;
            }
        }

        if (cpu != null && board != null) {
            String s1 = cpu.getSpecs().get("socket");
            String s2 = board.getSpecs().get("socket");
            if (s1 != null && s2 != null && !s1.equalsIgnoreCase(s2)) {
                errors.add("Сокет процессора (" + s1 + ") не подходит к материнской плате (" + s2 + ")");
            }
        }

        if (board != null) {
            String boardRam = board.getSpecs().get("ram_type");
            for (Product ram : rams) {
                String t = ram.getSpecs().get("ram_type");
                if (boardRam != null && t != null && !boardRam.equalsIgnoreCase(t)) {
                    errors.add("Память \"" + ram.getName() + "\" (" + t + ") не подходит к материнской плате (" + boardRam + ")");
                }
            }
            int slots = num(board, "ram_slots");
            if (slots > 0 && rams.size() > slots) {
                errors.add("Модулей памяти больше, чем слотов на материнской плате (" + slots + ")");
            }
        }

        if (board != null && pcCase != null) {
            int b = sizeIndex(board.getSpecs().get("form_factor"));
            int c = sizeIndex(pcCase.getSpecs().get("form_factor"));
            if (b != -1 && c != -1 && b > c) {
                errors.add("Материнская плата " + board.getSpecs().get("form_factor")
                        + " не помещается в корпус " + pcCase.getSpecs().get("form_factor"));
            }
        }

        if (cooler != null) {
            String coolerSockets = cooler.getSpecs().get("sockets");
            if (cpu != null && coolerSockets != null) {
                String cpuSocket = cpu.getSpecs().get("socket");
                if (cpuSocket != null && !socketInList(coolerSockets, cpuSocket)) {
                    errors.add("Кулер \"" + cooler.getName() + "\" не подходит к сокету " + cpuSocket);
                }
            }
            if (cpu != null) {
                int cpuTdp = num(cpu, "tdp_w");
                int coolerTdp = num(cooler, "cooler_tdp_w");
                if (coolerTdp > 0 && cpuTdp > coolerTdp) {
                    errors.add("Кулер рассчитан на " + coolerTdp + " Вт, а процессору нужно " + cpuTdp + " Вт");
                }
            }
            if (pcCase != null) {
                int caseMax = num(pcCase, "max_cooler_height_mm");
                int height = num(cooler, "cooler_height_mm");
                if (caseMax > 0 && height > caseMax) {
                    errors.add("Кулер высотой " + height + " мм не помещается в корпус (максимум " + caseMax + " мм)");
                }
            }
        }

        if (board != null && !storages.isEmpty()) {
            int nvme = 0;
            int sata = 0;
            for (Product st : storages) {
                if ("NVMe".equalsIgnoreCase(st.getSpecs().get("storage_type"))) {
                    nvme++;
                } else {
                    sata++;
                }
            }
            int m2 = num(board, "m2_slots");
            int ports = num(board, "sata_ports");
            if (m2 > 0 && nvme > m2) {
                errors.add("NVMe-накопителей (" + nvme + ") больше, чем слотов M.2 на материнской плате (" + m2 + ")");
            }
            if (ports > 0 && sata > ports) {
                errors.add("SATA-накопителей (" + sata + ") больше, чем портов SATA на материнской плате (" + ports + ")");
            }
        }

        if (cpu != null || gpu != null) {
            if (psu == null) {
                warnings.add("Не выбран блок питания, мощность не проверена");
            } else {
                int need = powerNeeded(products);
                int have = num(psu, "psu_power_w");
                if (have > 0 && have < need) {
                    errors.add("Мощности блока питания (" + have + " Вт) не хватает, нужно минимум " + need + " Вт");
                }
            }
        }

        String missing = "";
        if (cpu == null) {
            missing = missing + " процессор,";
        }
        if (board == null) {
            missing = missing + " материнская плата,";
        }
        if (rams.isEmpty()) {
            missing = missing + " память,";
        }
        if (cooler == null) {
            missing = missing + " кулер процессора,";
        }
        if (storages.isEmpty()) {
            missing = missing + " накопитель,";
        }
        if (psu == null) {
            missing = missing + " блок питания,";
        }
        if (pcCase == null) {
            missing = missing + " корпус,";
        }
        if (!missing.isEmpty()) {
            warnings.add("В сборке пока нет:" + missing.substring(0, missing.length() - 1));
        }
    }

    public Map<String, Object> check(List<Long> productIds) {
        List<Product> products = loadProducts(productIds);
        List<String> errors = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        checkRules(products, errors, warnings);

        BigDecimal total = BigDecimal.ZERO;
        for (Product p : products) {
            total = total.add(p.getPrice());
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("compatible", errors.isEmpty());
        result.put("errors", errors);
        result.put("warnings", warnings);
        result.put("required_power_w", powerNeeded(products));
        result.put("total_price", total);
        return result;
    }

    public List<Product> compatible(Long baseId, Long categoryId) {
        Product base = productRepository.findById(baseId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Товар не найден"));

        List<Product> result = new ArrayList<>();
        for (Product candidate : productRepository.findByCategoryIdAndActiveTrue(categoryId)) {
            if (candidate.getId().equals(base.getId())) {
                continue;
            }
            List<Product> pair = new ArrayList<>();
            pair.add(base);
            pair.add(candidate);
            List<String> errors = new ArrayList<>();
            checkRules(pair, errors, new ArrayList<>());
            if (errors.isEmpty()) {
                result.add(candidate);
            }
        }
        return result;
    }
}
