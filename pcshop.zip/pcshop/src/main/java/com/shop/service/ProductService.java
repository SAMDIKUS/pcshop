package com.shop.service;

import com.shop.entity.Category;
import com.shop.entity.Product;
import com.shop.repository.CategoryRepository;
import com.shop.repository.ProductRepository;
import jakarta.persistence.criteria.MapJoin;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    public ProductService(ProductRepository productRepository, CategoryRepository categoryRepository) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
    }

    public List<Long> categoryWithChildren(Long categoryId) {
        List<Long> ids = new ArrayList<>();
        ids.add(categoryId);
        int i = 0;
        while (i < ids.size()) {
            for (Category c : categoryRepository.findByParentId(ids.get(i))) {
                ids.add(c.getId());
            }
            i++;
        }
        return ids;
    }

    private Specification<Product> hasSpec(String key, String value) {
        return (root, query, cb) -> {
            MapJoin<Product, String, String> join = root.joinMap("specs");
            return cb.and(cb.equal(join.key(), key), cb.equal(join.value(), value));
        };
    }

    public Map<String, Object> search(Long categoryId, Long brandId, BigDecimal priceMin, BigDecimal priceMax,
                                      String socket, String ramType, String formFactor, Boolean inStock,
                                      String sort, int page, int limit) {

        Specification<Product> spec = (root, query, cb) -> cb.isTrue(root.get("active"));

        if (categoryId != null) {
            List<Long> ids = categoryWithChildren(categoryId);
            spec = spec.and((root, query, cb) -> root.get("categoryId").in(ids));
        }
        if (brandId != null) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("brandId"), brandId));
        }
        if (priceMin != null) {
            spec = spec.and((root, query, cb) -> cb.greaterThanOrEqualTo(root.get("price"), priceMin));
        }
        if (priceMax != null) {
            spec = spec.and((root, query, cb) -> cb.lessThanOrEqualTo(root.get("price"), priceMax));
        }
        if (inStock != null && inStock) {
            spec = spec.and((root, query, cb) -> cb.greaterThan(root.get("stockQuantity"), 0));
        }
        if (socket != null && !socket.isBlank()) {
            spec = spec.and(hasSpec("socket", socket));
        }
        if (ramType != null && !ramType.isBlank()) {
            spec = spec.and(hasSpec("ram_type", ramType));
        }
        if (formFactor != null && !formFactor.isBlank()) {
            spec = spec.and(hasSpec("form_factor", formFactor));
        }

        Sort order = Sort.by("id");
        if (sort != null) {
            switch (sort) {
                case "price_asc":
                    order = Sort.by("price").ascending();
                    break;
                case "price_desc":
                    order = Sort.by("price").descending();
                    break;
                case "name":
                    order = Sort.by("name").ascending();
                    break;
                case "rating":
                    order = Sort.by("avgRating").descending();
                    break;
                default:
                    break;
            }
        }

        if (page < 1) {
            page = 1;
        }
        if (limit < 1) {
            limit = 20;
        }
        if (limit > 100) {
            limit = 100;
        }

        Page<Product> result = productRepository.findAll(spec, PageRequest.of(page - 1, limit, order));

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("items", result.getContent());
        body.put("page", page);
        body.put("limit", limit);
        body.put("total", result.getTotalElements());
        body.put("total_pages", result.getTotalPages());
        return body;
    }
}
